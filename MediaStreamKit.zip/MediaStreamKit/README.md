# MediaStreamKit 🎬🔮

**Plataforma privada de comunicación P2P y sincronización de reproducción multimedia para dos nodos de usuario.**

---

## 📐 Arquitectura

```
app/
├── core/
│   ├── data/
│   │   ├── local/          # Room + SQLCipher (DB cifrada AES)
│   │   │   ├── dao/        # DAOs para todas las tablas
│   │   │   ├── entities/   # Entidades Room
│   │   │   └── converters/ # TypeConverters (Gson)
│   │   ├── remote/
│   │   │   ├── api/        # Retrofit (TMDB API)
│   │   │   ├── dto/        # DTOs de red
│   │   │   └── websocket/  # Ktor WebSocket client
│   │   └── repository/     # Implementaciones de repositorios
│   ├── domain/
│   │   ├── model/          # Modelos de dominio (puros Kotlin)
│   │   ├── repository/     # Interfaces de repositorios
│   │   └── usecase/        # (extensible)
│   ├── di/                 # Módulos Hilt
│   ├── network/            # PresenceManager, WebRtcManager, FCM
│   ├── security/           # AesEncryptionManager, PasswordHasher
│   ├── service/            # WorkManager workers, Services
│   └── utils/              # Result, extensiones
├── feature/
│   ├── splash/             # Splash con frases aleatorias
│   ├── auth/
│   │   ├── setup/          # Configuración inicial (2 perfiles)
│   │   └── login/          # Selección de perfil + biométrico + contraseña
│   ├── home/               # Dashboard LazyColumn/LazyRow
│   │   ├── HomeScreen
│   │   ├── HomeViewModel
│   │   ├── PresenceViewModel
│   │   ├── MediaDetailScreen
│   │   ├── MediaDetailViewModel
│   └── └── ...
│   ├── playback/           # ExoPlayer + controles personalizados
│   ├── sync/               # Sala de sincronización P2P
│   ├── chat/               # Chat cifrado AES-256 punto a punto
│   ├── ai/                 # Luna (Anthropic Claude) + Analytics
│   ├── call/               # WebRTC audio/video P2P
│   ├── notes/              # Bitácora de notas
│   └── settings/           # Temas, autoplay, biométrico
└── ui/
    ├── theme/              # Material You, 4 temas dinámicos
    ├── components/         # StarParticleCanvas, reutilizables
    └── navigation/         # NavGraph completo
```

---

## 🎨 Sistema de Temas

| Tema | Primary | Background |
|------|---------|-----------|
| Púrpura Cósmico (default) | `#6A1B9A` | `#120024` |
| Azul Galaxia | `#0D47A1` | `#000A1F` |
| Rosa Romántico | `#AD1457` | `#1A0010` |
| Negro Elegante | `#455A64` | `#050505` |

Persistido en **DataStore Preferences**. Switchable en runtime sin reiniciar la app.

---

## 🔐 Seguridad

- **Base de datos**: Room + **SQLCipher** (AES-256-CBC)
- **Mensajes de chat**: Cifrados con **AES/GCM/NoPadding** antes de almacenar
- **Archivos descargados**: Cifrados en bytes con AES antes de escribir a disco
- **Contraseñas**: SHA-256 x 10,000 iteraciones con salt aleatorio de 16 bytes
- **Biométrico**: `BiometricPrompt` API oficial (huella + reconocimiento facial)
- **Luna (IA)**: Aislada estrictamente — **sin acceso** a `messages_table` ni `contextual_messages`

---

## 🌐 Módulos de Red

### WebSocket (Ktor)
- Heartbeat cada **10 segundos** para presencia
- Reconexión automática con backoff de 3s
- Eventos: `presence_update`, `playback_sync`, `chat_message`, `room_created/joined/ready`, `network_lost`

### Sincronización de Reproducción
- Algoritmo de compensación de latencia basado en **Cristian / NTP**
- RTT = `localReceiveTime - clientEpochTime`
- Si `|posiciónLocal - posiciónRemota| > 500ms` → fuerza `seekTo()`
- En `network_lost` → broadcast `PAUSE` + diálogo modal de espera

### WebRTC (P2P Audio/Video)
- Servidores STUN: `stun.l.google.com:19302`
- Soporte TURN configurable (credenciales en `BuildConfig`)
- Señalización a través del WebSocket existente

---

## 🤖 Luna — Asistente de IA

Luna usa la **API de Anthropic (Claude Sonnet 4.6)** con **Function Calling**:

| Herramienta | Descripción |
|-------------|-------------|
| `add_to_shared_list(movie_id)` | Agrega título a lista compartida |
| `filter_catalog_by_genre(genre_id)` | Filtra catálogo local por género |
| `get_uncompleted_sagas()` | Sagas incompletas en lista compartida |
| `get_user_history(user_id)` | Historial de reproducción (no mensajes) |
| `analyze_cross_preferences()` | Análisis de afinidad cruzada |

**Restricción estricta**: Luna **nunca** accede a `messages_table` ni `contextual_messages`. Solo lee `playback_history_table` y `genre_preferences`.

---

## 🛠 Configuración Inicial

### 1. Claves de API

Edita `app/build.gradle.kts`:

```kotlin
buildConfigField("String", "TMDB_API_KEY", "\"TU_CLAVE_TMDB\"")
buildConfigField("String", "ANTHROPIC_API_KEY", "\"TU_CLAVE_ANTHROPIC\"")
buildConfigField("String", "WS_BASE_URL", "\"wss://tu-servidor.com/ws\"")
buildConfigField("String", "API_BASE_URL", "\"https://tu-servidor.com/api/\"")
```

### 2. Firebase

- Descarga `google-services.json` desde Firebase Console
- Colócalo en `/app/`
- Habilita **Cloud Messaging** y **Realtime Database**

### 3. Servidor Backend (Node.js / Python)

El cliente espera un servidor WebSocket con soporte para:
- `create_room` → responde `room_created { code }`
- `join_room`   → responde `room_joined` + `room_ready` a ambos
- `playback_sync` → relay al otro cliente de la sala
- `chat_message`  → relay + persistencia en PostgreSQL
- `heartbeat`     → actualiza timestamp de presencia
- `ice_candidate`, `webrtc_offer`, `webrtc_answer` → relay P2P

---

## 📦 Dependencias Clave

| Librería | Uso |
|----------|-----|
| Jetpack Compose + Material3 | UI declarativa |
| Hilt | Inyección de dependencias |
| Room + SQLCipher | DB local cifrada |
| Ktor Client | WebSocket |
| Retrofit + OkHttp | TMDB REST API |
| Media3 (ExoPlayer) | Reproducción de video |
| Firebase FCM | Push notifications |
| WorkManager | Descargas offline |
| Coil | Carga de imágenes |
| WebRTC (Stream) | Audio/video P2P |
| Biometric | Autenticación biométrica |
| DataStore | Preferencias de usuario |

---

## 🧪 Tests

```bash
# Unit tests
./gradlew test

# Instrumented tests (requiere emulador/dispositivo)
./gradlew connectedAndroidTest
```

---

## 🚀 Build de Producción

```bash
./gradlew assembleRelease
# o
./gradlew bundleRelease   # para Google Play (.aab)
```

ProGuard está configurado en `app/proguard-rules.pro` con reglas para todas las dependencias.

---

## 📱 Requisitos

- **Android**: API 26+ (Android 8.0 Oreo)
- **Target**: API 35 (Android 15)
- **Kotlin**: 2.0.0
- **Compose BOM**: 2024.06.00

---

## 🏗 Principios SOLID Aplicados

- **S** — Cada clase tiene una única responsabilidad (ViewModel, Repository, DAO, UseCase)
- **O** — Los repositorios son extensibles mediante interfaces
- **L** — Las implementaciones son sustituibles por sus interfaces Hilt
- **I** — Interfaces segregadas por dominio (`UserRepository`, `MediaRepository`, etc.)
- **D** — Todas las dependencias inyectadas via Hilt; cero `object` singleton manual

---

*MediaStreamKit — Tu universo privado de entretenimiento compartido* 🌙
