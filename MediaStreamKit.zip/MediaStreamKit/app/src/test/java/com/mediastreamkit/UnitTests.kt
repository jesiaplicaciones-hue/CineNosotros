package com.mediastreamkit

import com.mediastreamkit.core.security.PasswordHasher
import com.mediastreamkit.core.utils.generateRoomCode
import com.mediastreamkit.core.utils.safeCall
import com.mediastreamkit.core.utils.Result
import org.junit.Assert.*
import org.junit.Test

class PasswordHasherTest {

    private val hasher = PasswordHasher()

    @Test
    fun `encode and verify match`() {
        val password = "SecureP@ss123"
        val encoded  = hasher.encode(password)
        assertTrue("Hash should verify correctly", hasher.verifyEncoded(password, encoded))
    }

    @Test
    fun `wrong password does not verify`() {
        val encoded = hasher.encode("CorrectPassword")
        assertFalse("Wrong password should not verify",
            hasher.verifyEncoded("WrongPassword", encoded))
    }

    @Test
    fun `two encodes of same password produce different hashes`() {
        val pw = "SamePassword"
        val hash1 = hasher.encode(pw)
        val hash2 = hasher.encode(pw)
        assertNotEquals("Salts should differ", hash1, hash2)
        // Both should still verify
        assertTrue(hasher.verifyEncoded(pw, hash1))
        assertTrue(hasher.verifyEncoded(pw, hash2))
    }
}

class RoomCodeTest {

    @Test
    fun `room code is 6 characters`() {
        val code = generateRoomCode()
        assertEquals(6, code.length)
    }

    @Test
    fun `room code contains only alphanumeric uppercase`() {
        repeat(20) {
            val code = generateRoomCode()
            assertTrue("Code should be alphanumeric uppercase",
                code.all { it.isLetterOrDigit() && (it.isDigit() || it.isUpperCase()) })
        }
    }

    @Test
    fun `custom length room code`() {
        val code = generateRoomCode(8)
        assertEquals(8, code.length)
    }
}

class SafeCallTest {

    @Test
    fun `safeCall returns success on valid block`() {
        val result = safeCall { 42 }
        assertTrue(result is Result.Success)
        assertEquals(42, (result as Result.Success).data)
    }

    @Test
    fun `safeCall returns error on exception`() {
        val result = safeCall<Int> { throw IllegalStateException("Test error") }
        assertTrue(result is Result.Error)
        assertEquals("Test error", (result as Result.Error).message)
    }

    @Test
    fun `getOrNull returns data on success`() {
        val result = safeCall { "hello" }
        assertEquals("hello", result.getOrNull())
    }

    @Test
    fun `getOrNull returns null on error`() {
        val result = safeCall<String> { throw RuntimeException("fail") }
        assertNull(result.getOrNull())
    }
}
