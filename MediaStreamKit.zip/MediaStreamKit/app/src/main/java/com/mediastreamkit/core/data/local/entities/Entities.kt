package com.mediastreamkit.core.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.mediastreamkit.core.data.local.converters.RoomTypeConverters

// ─── UserProfile ──────────────────────────────────────────────────────────────

@Entity(tableName = "user_profiles")
data class UserProfileEntity(
    @PrimaryKey val id: Int,
    val username: String,
    val avatarId: Int,
    val profilePicture: ByteArray?,
    val passwordHash: String,
    val createdAt: Long = System.currentTimeMillis()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is UserProfileEntity) return false
        return id == other.id
    }
    override fun hashCode(): Int = id
}

// ─── Media Items ──────────────────────────────────────────────────────────────

@Entity(tableName = "media_items")
@TypeConverters(RoomTypeConverters::class)
data class MediaItemEntity(
    @PrimaryKey val id: Int,
    val tmdbId: Int,
    val title: String,
    val posterPath: String?,
    val backdropPath: String?,
    val runtimeMinutes: Int,
    val genres: List<String>,         // stored as JSON
    val releaseDate: String,
    val overview: String,
    val sagaId: Int?,
    val sagaName: String?,
    val category: String,             // enum name
    val isWatched: Boolean = false,
    val watchedProgress: Float = 0f,
    val isDownloaded: Boolean = false,
    val downloadPath: String? = null,
    val cachedAt: Long = System.currentTimeMillis()
)

// ─── Chat Messages ────────────────────────────────────────────────────────────

@Entity(
    tableName = "chat_messages",
    indices = [Index("mediaId"), Index("senderId"), Index("timestamp")]
)
data class ChatMessageEntity(
    @PrimaryKey val messageId: String,
    val mediaId: Int?,
    val senderId: Int,
    val payloadText: String,   // AES-256 encrypted ciphertext (Base64)
    val messageType: String,
    val blobUri: String?,
    val timestamp: Long,
    val isEncrypted: Boolean = true,
    val reactionEmoji: String? = null,
    val isDelivered: Boolean = false,
    val isRead: Boolean = false
)

// ─── Contextual Messages (media-linked chat) ──────────────────────────────────

@Entity(
    tableName = "contextual_messages",
    foreignKeys = [
        ForeignKey(
            entity = MediaItemEntity::class,
            parentColumns = ["id"],
            childColumns = ["media_id"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("media_id"), Index("user_id")]
)
data class ContextualMessageEntity(
    @PrimaryKey val message_id: String,
    @ColumnInfo(name = "media_id") val mediaId: Int?,
    @ColumnInfo(name = "user_id") val userId: Int,
    val payload_text: String,
    val timestamp: Long
)

// ─── Playback History (Luna analytics — NOT chat) ─────────────────────────────

@Entity(
    tableName = "playback_history_table",
    indices = [Index("mediaId"), Index("userId"), Index("timestamp")]
)
data class PlaybackEventEntity(
    @PrimaryKey(autoGenerate = true) val eventId: Long = 0,
    val mediaId: Int,
    val userId: Int,
    val eventType: String,          // PlaybackState name
    val positionSeconds: Float,
    val totalWatchedSeconds: Long,
    val timestamp: Long = System.currentTimeMillis()
)

// ─── Shared List ──────────────────────────────────────────────────────────────

@Entity(
    tableName = "shared_list",
    foreignKeys = [
        ForeignKey(
            entity = MediaItemEntity::class,
            parentColumns = ["id"],
            childColumns = ["mediaId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("mediaId")]
)
data class SharedListEntity(
    @PrimaryKey val mediaId: Int,
    val addedByUserId: Int,
    val addedAt: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false
)

// ─── Notes / Bitácora ─────────────────────────────────────────────────────────

@Entity(
    tableName = "notes",
    indices = [Index("userId"), Index("mediaId")]
)
data class NoteEntity(
    @PrimaryKey val noteId: String,
    val userId: Int,
    val mediaId: Int?,
    val content: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isPinned: Boolean = false
)

// ─── Genre Preferences ────────────────────────────────────────────────────────

@Entity(
    tableName = "genre_preferences",
    primaryKeys = ["userId", "genreId"]
)
data class GenrePreferenceEntity(
    val userId: Int,
    val genreId: Int,
    val genreName: String,
    val watchCount: Int = 0,
    val totalMinutesWatched: Long = 0L
)

// ─── Download Queue ───────────────────────────────────────────────────────────

@Entity(tableName = "download_queue")
data class DownloadQueueEntity(
    @PrimaryKey val mediaId: Int,
    val title: String,
    val streamUrl: String,
    val encryptedFilePath: String? = null,
    val status: String = "PENDING",   // PENDING, DOWNLOADING, COMPLETE, FAILED
    val progressPercent: Int = 0,
    val workerId: String? = null,
    val enqueuedAt: Long = System.currentTimeMillis()
)
