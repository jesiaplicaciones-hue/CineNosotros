package com.mediastreamkit.core.data.remote.websocket

import io.ktor.client.*
import io.ktor.client.plugins.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.serialization.json.*
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

// ─── WebSocket Events ─────────────────────────────────────────────────────────

sealed class WsEvent {
    data class Connected(val sessionId: String) : WsEvent()
    object Disconnected : WsEvent()
    data class PresenceUpdate(val userId: Int, val status: String) : WsEvent()
    data class PlaybackSync(val payload: String) : WsEvent()
    data class ChatMessage(val payload: String) : WsEvent()
    data class RoomCreated(val code: String) : WsEvent()
    data class RoomJoined(val code: String) : WsEvent()
    data class RoomReady(val code: String) : WsEvent()
    data class NetworkLost(val roomCode: String) : WsEvent()
    data class Error(val cause: Throwable) : WsEvent()
}

@Singleton
class MskWebSocketClient @Inject constructor(
    private val httpClient: HttpClient,
    private val json: Json
) {
    private val _events = MutableSharedFlow<WsEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<WsEvent> = _events.asSharedFlow()

    private val sendChannel = Channel<String>(Channel.UNLIMITED)
    private var session: WebSocketSession? = null
    private var heartbeatJob: Job? = null
    private var sessionJob: Job? = null
    private var currentUserId: Int = -1
    private var wsUrl: String = ""

    fun initialize(userId: Int, baseWsUrl: String) {
        currentUserId = userId
        wsUrl = baseWsUrl
    }

    fun connect(scope: CoroutineScope) {
        sessionJob?.cancel()
        sessionJob = scope.launch {
            while (isActive) {
                try {
                    httpClient.webSocket(wsUrl) {
                        session = this
                        Timber.d("WS connected")
                        _events.emit(WsEvent.Connected(sessionId = "ws-${System.currentTimeMillis()}"))
                        startHeartbeat(scope)

                        // Concurrent send + receive
                        val sendJob = launch {
                            for (msg in sendChannel) {
                                send(msg)
                            }
                        }
                        try {
                            for (frame in incoming) {
                                if (frame is Frame.Text) {
                                    handleIncoming(frame.readText())
                                }
                            }
                        } finally {
                            sendJob.cancel()
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Timber.e(e, "WS error — retrying in 3s")
                    _events.emit(WsEvent.Error(e))
                    _events.emit(WsEvent.Disconnected)
                }
                heartbeatJob?.cancel()
                delay(3_000)
            }
        }
    }

    private fun startHeartbeat(scope: CoroutineScope) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(10_000)
                sendRaw(buildJsonObject {
                    put("type", "heartbeat")
                    put("userId", currentUserId)
                    put("epoch", System.currentTimeMillis())
                }.toString())
            }
        }
    }

    private suspend fun handleIncoming(raw: String) {
        try {
            val obj = json.parseToJsonElement(raw).jsonObject
            when (obj["type"]?.jsonPrimitive?.content) {
                "presence_update" -> _events.emit(WsEvent.PresenceUpdate(
                    userId = obj["userId"]!!.jsonPrimitive.int,
                    status = obj["status"]!!.jsonPrimitive.content
                ))
                "playback_sync" -> _events.emit(WsEvent.PlaybackSync(raw))
                "chat_message"  -> _events.emit(WsEvent.ChatMessage(raw))
                "room_created"  -> _events.emit(WsEvent.RoomCreated(
                    code = obj["code"]!!.jsonPrimitive.content))
                "room_joined"   -> _events.emit(WsEvent.RoomJoined(
                    code = obj["code"]!!.jsonPrimitive.content))
                "room_ready"    -> _events.emit(WsEvent.RoomReady(
                    code = obj["code"]!!.jsonPrimitive.content))
                "network_lost"  -> _events.emit(WsEvent.NetworkLost(
                    roomCode = obj["roomCode"]!!.jsonPrimitive.content))
                else -> Timber.w("Unknown WS event: $raw")
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to parse WS frame: $raw")
        }
    }

    fun sendRaw(payload: String) {
        sendChannel.trySend(payload)
    }

    fun createRoom(mediaId: Int) {
        sendRaw(buildJsonObject {
            put("type", "create_room")
            put("userId", currentUserId)
            put("mediaId", mediaId)
        }.toString())
    }

    fun joinRoom(roomCode: String) {
        sendRaw(buildJsonObject {
            put("type", "join_room")
            put("userId", currentUserId)
            put("code", roomCode)
        }.toString())
    }

    fun sendPlaybackState(
        state: String, timestamp: Float, roomCode: String, mediaId: Int
    ) {
        sendRaw(buildJsonObject {
            put("type", "playback_sync")
            put("playbackState", state)
            put("timestampSeconds", timestamp)
            put("clientEpochTime", System.currentTimeMillis())
            put("roomCode", roomCode)
            put("mediaId", mediaId)
        }.toString())
    }

    fun sendChatMessage(
        cipherText: String, mediaId: Int?, messageId: String, msgType: String
    ) {
        sendRaw(buildJsonObject {
            put("type", "chat_message")
            put("messageId", messageId)
            put("senderId", currentUserId)
            mediaId?.let { put("mediaId", it) }
            put("payloadText", cipherText)
            put("messageType", msgType)
            put("timestamp", System.currentTimeMillis())
        }.toString())
    }

    fun disconnect() {
        heartbeatJob?.cancel()
        sessionJob?.cancel()
        session = null
    }
}
