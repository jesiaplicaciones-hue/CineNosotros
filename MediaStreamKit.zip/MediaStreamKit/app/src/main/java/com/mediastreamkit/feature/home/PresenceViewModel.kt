package com.mediastreamkit.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.BuildConfig
import com.mediastreamkit.core.data.remote.websocket.MskWebSocketClient
import com.mediastreamkit.core.domain.model.PresenceStatus
import com.mediastreamkit.core.domain.repository.SettingsRepository
import com.mediastreamkit.core.network.PresenceManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PresenceViewModel @Inject constructor(
    private val wsClient: MskWebSocketClient,
    private val presenceManager: PresenceManager,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val myStatus: StateFlow<PresenceStatus>      = presenceManager.myStatus
    val partnerStatus: StateFlow<PresenceStatus> = presenceManager.partnerStatus

    fun connect() {
        viewModelScope.launch {
            val userId = settingsRepository.getActiveUserId()
            wsClient.initialize(userId, BuildConfig.WS_BASE_URL)
            wsClient.connect(viewModelScope)
            presenceManager.start(userId, viewModelScope)
        }
    }

    fun disconnect() {
        presenceManager.stop()
        wsClient.disconnect()
    }

    override fun onCleared() {
        disconnect()
        super.onCleared()
    }
}
