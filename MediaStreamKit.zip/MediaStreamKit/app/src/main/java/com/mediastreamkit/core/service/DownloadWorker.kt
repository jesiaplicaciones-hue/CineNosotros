package com.mediastreamkit.core.service

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.mediastreamkit.core.data.local.dao.DownloadQueueDao
import com.mediastreamkit.core.data.local.dao.MediaItemDao
import com.mediastreamkit.core.security.AesEncryptionManager
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream

@HiltWorker
class DownloadWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val okHttpClient: OkHttpClient,
    private val aes: AesEncryptionManager,
    private val downloadQueueDao: DownloadQueueDao,
    private val mediaItemDao: MediaItemDao
) : CoroutineWorker(appContext, params) {

    companion object {
        const val KEY_MEDIA_ID  = "media_id"
        const val KEY_TITLE     = "title"
        const val KEY_STREAM_URL = "stream_url"

        fun buildRequest(mediaId: Int, title: String, streamUrl: String): OneTimeWorkRequest =
            OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(workDataOf(
                    KEY_MEDIA_ID   to mediaId,
                    KEY_STREAM_URL to streamUrl,
                    KEY_TITLE      to title
                ))
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build())
                .addTag("download_$mediaId")
                .build()
    }

    override suspend fun doWork(): Result {
        val mediaId   = inputData.getInt(KEY_MEDIA_ID, -1)
        val streamUrl = inputData.getString(KEY_STREAM_URL) ?: return Result.failure()
        val title     = inputData.getString(KEY_TITLE) ?: "unknown"

        if (mediaId == -1) return Result.failure()

        return try {
            downloadQueueDao.updateProgress(mediaId, "DOWNLOADING", 0)

            // Download file
            val request = Request.Builder().url(streamUrl).build()
            val response = okHttpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                downloadQueueDao.updateProgress(mediaId, "FAILED", 0)
                return Result.retry()
            }

            val bytes = response.body?.bytes() ?: run {
                downloadQueueDao.updateProgress(mediaId, "FAILED", 0)
                return Result.failure()
            }

            // AES-256 encrypt the file
            val encrypted = aes.encryptBytes(bytes)

            // Write to private app storage
            val outputDir  = File(applicationContext.filesDir, "downloads").also { it.mkdirs() }
            val outputFile = File(outputDir, "msk_${mediaId}.enc")
            FileOutputStream(outputFile).use { it.write(encrypted) }

            // Update database
            downloadQueueDao.updateProgress(mediaId, "COMPLETE", 100)
            mediaItemDao.updateDownloadState(mediaId, true, outputFile.absolutePath)

            Timber.d("Download complete for mediaId=$mediaId → ${outputFile.absolutePath}")
            Result.success()

        } catch (e: Exception) {
            Timber.e(e, "Download failed for mediaId=$mediaId")
            downloadQueueDao.updateProgress(mediaId, "FAILED", 0)
            Result.retry()
        }
    }
}
