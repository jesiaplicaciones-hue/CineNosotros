package com.mediastreamkit.feature.playback

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.ui.PlayerView
import com.mediastreamkit.core.domain.model.MediaItem
import com.mediastreamkit.feature.sync.SyncViewModel
import kotlinx.coroutines.delay

@Composable
fun PlaybackScreen(
    mediaItem: MediaItem,
    roomCode: String? = null,
    onBack: () -> Unit,
    onOpenChat: (Int) -> Unit,
    onOpenSync: (Int) -> Unit,
    viewModel: PlaybackViewModel = hiltViewModel(),
    syncViewModel: SyncViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var controlsVisible by remember { mutableStateOf(true) }

    // Wire sync callbacks to player
    LaunchedEffect(Unit) {
        viewModel.initialize(mediaItem)
        viewModel.onPlay  = { pos -> syncViewModel.onLocalPlay(pos) }
        viewModel.onPause = { pos -> syncViewModel.onLocalPause(pos) }
        viewModel.onSeek  = { pos -> syncViewModel.onLocalSeek(pos) }

        syncViewModel.attachPlayerCallbacks(
            onSeek      = { sec -> viewModel.seekToSeconds(sec) },
            onPlayPause = { play -> viewModel.forcePlayPause(play) }
        )
    }

    // Auto-hide controls
    LaunchedEffect(controlsVisible) {
        if (controlsVisible) {
            delay(4_000)
            controlsVisible = false
        }
    }

    // Next episode dialog
    if (state.showNextDialog && state.nextMediaOptions.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = viewModel::dismissNextDialog,
            title = { Text("¿Siguiente?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Selecciona el próximo contenido:",
                        style = MaterialTheme.typography.bodyMedium)
                    state.nextMediaOptions.forEach { next ->
                        Card(
                            onClick = { viewModel.playNext(next) },
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Text(next.title,
                                modifier = Modifier.padding(12.dp),
                                style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = viewModel::dismissNextDialog) { Text("Cerrar") }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable { controlsVisible = !controlsVisible }
    ) {
        // ExoPlayer surface
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false  // we use custom controls
                }
            },
            update = { playerView ->
                playerView.player = viewModel.player
            },
            modifier = Modifier.fillMaxSize()
        )

        // Buffering overlay
        AnimatedVisibility(
            visible = state.isBuffering,
            modifier = Modifier.align(Alignment.Center)
        ) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }

        // Custom controls overlay
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            PlaybackControlsOverlay(
                state = state,
                onBack = onBack,
                onPlayPause = viewModel::togglePlayPause,
                onSeek = { viewModel.seekTo(it) },
                onChatClick = { mediaItem.id.let(onOpenChat) },
                onSyncClick = { mediaItem.id.let(onOpenSync) }
            )
        }
    }
}

@Composable
private fun PlaybackControlsOverlay(
    state: PlaybackUiState,
    onBack: () -> Unit,
    onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onChatClick: () -> Unit,
    onSyncClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White)
            }
            Text(
                text = state.currentMedia?.title ?: "",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            IconButton(onClick = onSyncClick) {
                Icon(Icons.Default.Sync, "Sincronizar", tint = Color.White)
            }
            IconButton(onClick = onChatClick) {
                Icon(Icons.Default.Chat, "Chat", tint = Color.White)
            }
        }

        // Center play/pause
        Row(
            modifier = Modifier.align(Alignment.Center),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { onSeek(((state.positionMs - 10_000)).coerceAtLeast(0L)) },
                modifier = Modifier.size(56.dp)
            ) {
                Icon(Icons.Default.Replay10, "Retroceder", tint = Color.White,
                    modifier = Modifier.size(36.dp))
            }

            FilledIconButton(
                onClick = onPlayPause,
                modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color.White.copy(alpha = 0.15f))
            ) {
                Icon(
                    imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (state.isPlaying) "Pausar" else "Reproducir",
                    tint = Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }

            IconButton(
                onClick = { onSeek(state.positionMs + 10_000) },
                modifier = Modifier.size(56.dp)
            ) {
                Icon(Icons.Default.Forward10, "Avanzar", tint = Color.White,
                    modifier = Modifier.size(36.dp))
            }
        }

        // Bottom progress bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .padding(horizontal = 16.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(formatMs(state.positionMs), style = MaterialTheme.typography.labelSmall,
                    color = Color.White)
                Text(formatMs(state.durationMs), style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.7f))
            }
            Spacer(Modifier.height(4.dp))
            if (state.durationMs > 0L) {
                Slider(
                    value = state.positionMs.toFloat() / state.durationMs.toFloat(),
                    onValueChange = { onSeek((it * state.durationMs).toLong()) },
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                    )
                )
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = ms / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
