package com.mediastreamkit.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.data.remote.websocket.MskWebSocketClient
import com.mediastreamkit.core.data.remote.websocket.WsEvent
import com.mediastreamkit.core.domain.model.ChatMessage
import com.mediastreamkit.core.domain.model.MessageType
import com.mediastreamkit.core.domain.repository.ChatRepository
import com.mediastreamkit.core.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import java.util.UUID
import javax.inject.Inject

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val isLoading: Boolean = false,
    val myUserId: Int = -1,
    val mediaId: Int? = null   // null = general chat; non-null = contextual
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val wsClient: MskWebSocketClient,
    private val settingsRepository: SettingsRepository,
    private val json: Json
) : ViewModel() {

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    fun initialize(mediaId: Int? = null) {
        viewModelScope.launch {
            val userId = settingsRepository.getActiveUserId()
            _state.update { it.copy(myUserId = userId, mediaId = mediaId) }

            // Observe local messages
            val flow = if (mediaId == null)
                chatRepository.observeGeneralChat()
            else
                chatRepository.observeContextualChat(mediaId)

            flow.collect { msgs ->
                _state.update { it.copy(messages = msgs) }
                chatRepository.markAllRead(userId)
            }
        }

        // Observe incoming WS chat messages
        viewModelScope.launch {
            wsClient.events
                .filterIsInstance<WsEvent.ChatMessage>()
                .collect { event -> handleIncomingWsMessage(event.payload) }
        }
    }

    private suspend fun handleIncomingWsMessage(raw: String) {
        try {
            val obj = json.parseToJsonElement(raw).jsonObject
            val message = ChatMessage(
                messageId   = obj["messageId"]?.jsonPrimitive?.content ?: UUID.randomUUID().toString(),
                mediaId     = obj["mediaId"]?.jsonPrimitive?.intOrNull,
                senderId    = obj["senderId"]?.jsonPrimitive?.int ?: return,
                payloadText = obj["payloadText"]?.jsonPrimitive?.content ?: return,
                messageType = MessageType.valueOf(
                    obj["messageType"]?.jsonPrimitive?.content ?: "TEXT"),
                blobUri     = null,
                timestamp   = obj["timestamp"]?.jsonPrimitive?.long ?: System.currentTimeMillis(),
                isEncrypted = true
            )
            // Only persist if it's from the other user (we already saved our own)
            if (message.senderId != _state.value.myUserId) {
                chatRepository.sendMessage(message)
            }
        } catch (_: Exception) {}
    }

    fun onInputChange(text: String) {
        _state.update { it.copy(inputText = text) }
    }

    fun sendMessage() {
        val s = _state.value
        val text = s.inputText.trim()
        if (text.isBlank()) return

        viewModelScope.launch {
            val message = ChatMessage(
                messageId   = UUID.randomUUID().toString(),
                mediaId     = s.mediaId,
                senderId    = s.myUserId,
                payloadText = text,
                messageType = MessageType.TEXT,
                blobUri     = null,
                timestamp   = System.currentTimeMillis()
            )
            _state.update { it.copy(inputText = "") }
            // Persist locally
            chatRepository.sendMessage(message)
            // Send over WS
            wsClient.sendChatMessage(
                cipherText = text,  // will be encrypted inside repository
                mediaId    = s.mediaId,
                messageId  = message.messageId,
                msgType    = MessageType.TEXT.name
            )
        }
    }

    fun sendReaction(messageId: String, emoji: String) {
        val s = _state.value
        viewModelScope.launch {
            val reaction = ChatMessage(
                messageId   = UUID.randomUUID().toString(),
                mediaId     = s.mediaId,
                senderId    = s.myUserId,
                payloadText = emoji,
                messageType = MessageType.REACTION,
                blobUri     = null,
                timestamp   = System.currentTimeMillis(),
                reactionEmoji = emoji
            )
            chatRepository.sendMessage(reaction)
            wsClient.sendChatMessage(
                cipherText = emoji,
                mediaId    = s.mediaId,
                messageId  = reaction.messageId,
                msgType    = MessageType.REACTION.name
            )
        }
    }
}
