package com.mediastreamkit.feature.playback

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.mediastreamkit.core.domain.model.AutoPlayMode
import com.mediastreamkit.core.domain.model.MediaItem
import com.mediastreamkit.core.domain.model.PlaybackState
import com.mediastreamkit.core.domain.repository.AnalyticsRepository
import com.mediastreamkit.core.domain.repository.MediaRepository
import com.mediastreamkit.core.domain.repository.SettingsRepository
import com.mediastreamkit.core.domain.model.PlaybackEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class NextEpisodeAction { ASK, AUTO, MANUAL }

data class PlaybackUiState(
    val currentMedia: MediaItem? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPercent: Int = 0,
    val isBuffering: Boolean = false,
    val showNextDialog: Boolean = false,
    val nextMediaOptions: List<MediaItem> = emptyList(),
    val autoPlayMode: AutoPlayMode = AutoPlayMode.ASK,
    val error: String? = null
)

@HiltViewModel
class PlaybackViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val mediaRepository: MediaRepository,
    private val analyticsRepository: AnalyticsRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    var player: ExoPlayer? = null
        private set

    // Callback to sync module
    var onPlay:  ((Float) -> Unit)? = null
    var onPause: ((Float) -> Unit)? = null
    var onSeek:  ((Float) -> Unit)? = null

    private var activeUserId: Int = 0

    fun initialize(mediaItem: MediaItem) {
        viewModelScope.launch {
            activeUserId = settingsRepository.getActiveUserId()
            val settings = settingsRepository.observeSettings().first()
            _state.update { it.copy(currentMedia = mediaItem, autoPlayMode = settings.autoPlayMode) }

            setupPlayer(mediaItem)
        }
    }

    private fun setupPlayer(media: MediaItem) {
        player?.release()
        val exo = ExoPlayer.Builder(context).build()
        player = exo

        // Use HTTPS stream URL — in production derive from your media server
        val streamUrl = "https://your-stream-server.com/stream/${media.id}"
        exo.setMediaItem(ExoMediaItem.fromUri(streamUrl))
        exo.prepare()
        exo.playWhenReady = true

        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                val posSec = exo.currentPosition / 1000f
                _state.update { it.copy(isPlaying = isPlaying) }
                if (isPlaying) onPlay?.invoke(posSec)
                else onPause?.invoke(posSec)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> _state.update { it.copy(isBuffering = true) }
                    Player.STATE_READY     -> _state.update { it.copy(
                        isBuffering = false,
                        durationMs = exo.duration.coerceAtLeast(0L)
                    ) }
                    Player.STATE_ENDED     -> onMediaEnded()
                    else -> {}
                }
            }
        })

        // Position polling
        viewModelScope.launch {
            while (true) {
                delay(500)
                val pos = player?.currentPosition ?: 0L
                val dur = player?.duration?.coerceAtLeast(0L) ?: 0L
                val pct = player?.bufferedPercentage ?: 0
                _state.update { it.copy(
                    positionMs = pos,
                    durationMs = dur,
                    bufferedPercent = pct
                ) }
                // Update watch progress
                if (dur > 0L) {
                    val progress = pos.toFloat() / dur.toFloat()
                    _state.value.currentMedia?.let { m ->
                        if (progress > 0.05f) mediaRepository.markWatched(m.id, progress)
                    }
                }
            }
        }
    }

    private fun onMediaEnded() {
        viewModelScope.launch {
            val media = _state.value.currentMedia ?: return@launch

            // 1. Mark watched
            mediaRepository.markWatched(media.id, 1f)

            // 2. Record analytics event
            analyticsRepository.recordPlaybackEvent(PlaybackEvent(
                mediaId = media.id,
                userId = activeUserId,
                eventType = PlaybackState.ENDED,
                positionSeconds = (player?.duration ?: 0L) / 1000f,
                timestamp = System.currentTimeMillis()
            ))

            // 3. Fetch recommendations (3 items)
            val recommendations = mediaRepository.getRecommendations(media.id).getOrNull() ?: emptyList()

            when (_state.value.autoPlayMode) {
                AutoPlayMode.AUTO   -> {
                    recommendations.firstOrNull()?.let { next -> initialize(next) }
                }
                AutoPlayMode.ASK    -> {
                    _state.update { it.copy(
                        showNextDialog = true,
                        nextMediaOptions = recommendations
                    ) }
                }
                AutoPlayMode.MANUAL -> { /* Do nothing — user controls */ }
            }
        }
    }

    fun playNext(media: MediaItem) {
        _state.update { it.copy(showNextDialog = false, nextMediaOptions = emptyList()) }
        initialize(media)
    }

    fun dismissNextDialog() {
        _state.update { it.copy(showNextDialog = false) }
    }

    fun togglePlayPause() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
    }

    fun seekTo(positionMs: Long) {
        player?.seekTo(positionMs)
        onSeek?.invoke(positionMs / 1000f)
    }

    fun seekToSeconds(seconds: Float) = seekTo((seconds * 1000).toLong())

    fun forcePlayPause(play: Boolean) {
        if (play) player?.play() else player?.pause()
    }

    override fun onCleared() {
        player?.release()
        player = null
        super.onCleared()
    }
}
