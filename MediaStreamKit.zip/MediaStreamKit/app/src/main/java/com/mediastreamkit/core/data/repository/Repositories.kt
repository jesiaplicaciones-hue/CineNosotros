package com.mediastreamkit.core.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import com.mediastreamkit.core.data.local.dao.*
import com.mediastreamkit.core.data.local.entities.*
import com.mediastreamkit.core.data.remote.api.TmdbApi
import com.mediastreamkit.core.domain.model.*
import com.mediastreamkit.core.domain.repository.*
import com.mediastreamkit.core.security.AesEncryptionManager
import com.mediastreamkit.core.security.PasswordHasher
import com.mediastreamkit.core.utils.*
import kotlinx.coroutines.flow.*
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

// ─── Mappers ──────────────────────────────────────────────────────────────────

private fun UserProfileEntity.toDomain() = UserProfile(
    id = id, username = username, avatarId = avatarId,
    profilePicture = profilePicture, passwordHash = passwordHash
)

private fun UserProfile.toEntity() = UserProfileEntity(
    id = id, username = username, avatarId = avatarId,
    profilePicture = profilePicture, passwordHash = passwordHash
)

private fun MediaItemEntity.toDomain() = MediaItem(
    id = id, tmdbId = tmdbId, title = title,
    posterPath = posterPath, backdropPath = backdropPath,
    runtimeMinutes = runtimeMinutes, genres = genres,
    releaseDate = releaseDate, overview = overview,
    sagaId = sagaId, sagaName = sagaName,
    category = MediaCategory.valueOf(category),
    isWatched = isWatched, watchedProgress = watchedProgress,
    isDownloaded = isDownloaded
)

private fun ChatMessageEntity.toDomain() = ChatMessage(
    messageId = messageId, mediaId = mediaId, senderId = senderId,
    payloadText = payloadText, messageType = MessageType.valueOf(messageType),
    blobUri = blobUri, timestamp = timestamp, isEncrypted = isEncrypted,
    reactionEmoji = reactionEmoji, isDelivered = isDelivered, isRead = isRead
)

// ─── UserRepository ────────────────────────────────────────────────────────────

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val dao: UserProfileDao,
    private val hasher: PasswordHasher
) : UserRepository {

    override fun observeProfiles(): Flow<List<UserProfile>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun getProfile(id: Int): UserProfile? = dao.getById(id)?.toDomain()

    override suspend fun saveProfile(profile: UserProfile) = dao.upsert(profile.toEntity())

    override suspend fun profilesExist(): Boolean = dao.count() >= 2

    override suspend fun verifyPassword(userId: Int, password: String): Boolean {
        val entity = dao.getById(userId) ?: return false
        return hasher.verifyEncoded(password, entity.passwordHash)
    }
}

// ─── MediaRepository ───────────────────────────────────────────────────────────

@Singleton
class MediaRepositoryImpl @Inject constructor(
    private val dao: MediaItemDao,
    private val tmdbApi: TmdbApi
) : MediaRepository {

    override fun observeAll() = dao.observeAll().map { it.map { e -> e.toDomain() } }
    override fun observeByCategory(category: MediaCategory) =
        dao.observeByCategory(category.name).map { it.map { e -> e.toDomain() } }
    override fun observeContinueWatching() =
        dao.observeContinueWatching().map { it.map { e -> e.toDomain() } }
    override fun observeHistory() = dao.observeHistory().map { it.map { e -> e.toDomain() } }
    override fun observeDownloaded() = dao.observeDownloaded().map { it.map { e -> e.toDomain() } }
    override suspend fun getById(id: Int) = dao.getById(id)?.toDomain()

    override suspend fun indexFromCsv(csv: String): Result<Int> = safeSuspendCall {
        // Parse CSV, deduplicate via Set, search TMDB for each
        val titles = csv.split("\n", ",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toSet()

        var indexed = 0
        titles.forEach { title ->
            try {
                val results = tmdbApi.searchMovie(title)
                val movie = results.results.firstOrNull() ?: return@forEach
                val detail = tmdbApi.getMovieDetail(movie.id)
                val entity = MediaItemEntity(
                    id = detail.id,
                    tmdbId = detail.id,
                    title = detail.title,
                    posterPath = detail.posterPath,
                    backdropPath = detail.backdropPath,
                    runtimeMinutes = detail.runtime ?: 0,
                    genres = detail.genres.map { it.name },
                    releaseDate = detail.releaseDate ?: "",
                    overview = detail.overview ?: "",
                    sagaId = detail.collection?.id,
                    sagaName = detail.collection?.name,
                    category = MediaCategory.CATEGORY_A.name
                )
                dao.upsert(entity)
                indexed++
            } catch (_: Exception) {}
        }
        indexed
    }

    override suspend fun markWatched(id: Int, progress: Float) =
        dao.updateWatchedState(id, isWatched = progress >= 0.9f, progress = progress)

    override suspend fun getRecommendations(mediaId: Int): Result<List<MediaItem>> =
        safeSuspendCall {
            val response = tmdbApi.getRecommendations(mediaId)
            response.results.take(3).map { dto ->
                MediaItem(
                    id = dto.id, tmdbId = dto.id, title = dto.title,
                    posterPath = dto.posterPath, backdropPath = dto.backdropPath,
                    runtimeMinutes = 0, genres = emptyList(),
                    releaseDate = dto.releaseDate ?: "", overview = dto.overview ?: "",
                    sagaId = null, sagaName = null, category = MediaCategory.CATEGORY_A
                )
            }
        }
}

// ─── ChatRepository ─────────────────────────────────────────────────────────────

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val dao: ChatMessageDao,
    private val aes: AesEncryptionManager
) : ChatRepository {

    override fun observeGeneralChat(): Flow<List<ChatMessage>> =
        dao.observeGeneralChat().map { list ->
            list.map { entity ->
                val decrypted = try { aes.decrypt(entity.payloadText) } catch (_: Exception) { "[encrypted]" }
                entity.toDomain().copy(payloadText = decrypted)
            }
        }

    override fun observeContextualChat(mediaId: Int): Flow<List<ChatMessage>> =
        dao.observeContextualChat(mediaId).map { list ->
            list.map { entity ->
                ChatMessage(
                    messageId = entity.message_id,
                    mediaId = entity.mediaId,
                    senderId = entity.userId,
                    payloadText = try { aes.decrypt(entity.payload_text) } catch (_: Exception) { "[encrypted]" },
                    messageType = MessageType.TEXT,
                    blobUri = null,
                    timestamp = entity.timestamp,
                    isEncrypted = true
                )
            }
        }

    override fun observeUnreadCount(myUserId: Int) = dao.observeUnreadCount(myUserId)

    override suspend fun sendMessage(message: ChatMessage) {
        val encrypted = aes.encrypt(message.payloadText)
        dao.insertMessage(
            ChatMessageEntity(
                messageId = message.messageId,
                mediaId = message.mediaId,
                senderId = message.senderId,
                payloadText = encrypted,
                messageType = message.messageType.name,
                blobUri = message.blobUri,
                timestamp = message.timestamp,
                isEncrypted = true,
                reactionEmoji = message.reactionEmoji
            )
        )
    }

    override suspend fun markAllRead(myUserId: Int) = dao.markAllRead(myUserId)
}

// ─── SharedListRepository ──────────────────────────────────────────────────────

@Singleton
class SharedListRepositoryImpl @Inject constructor(
    private val sharedListDao: SharedListDao,
    private val mediaDao: MediaItemDao
) : SharedListRepository {

    override fun observeSharedList() =
        sharedListDao.observeSharedList().map { it.map { e -> e.toDomain() } }

    override suspend fun addToSharedList(mediaId: Int, addedByUserId: Int) {
        sharedListDao.add(SharedListEntity(mediaId = mediaId, addedByUserId = addedByUserId))
    }

    override suspend fun removeFromSharedList(mediaId: Int) = sharedListDao.remove(mediaId)

    override suspend fun getUncompletedSagas() =
        sharedListDao.getUncompletedSagas().map { it.toDomain() }

    override suspend fun filterByGenre(genreId: Int): List<MediaItem> =
        mediaDao.observeAll().first().map { it.toDomain() }
            .filter { item -> item.genres.isNotEmpty() }

    override suspend fun exists(mediaId: Int) = sharedListDao.exists(mediaId)
}

// ─── NoteRepository ────────────────────────────────────────────────────────────

@Singleton
class NoteRepositoryImpl @Inject constructor(private val dao: NoteDao) : NoteRepository {

    override fun observeNotes(userId: Int) =
        dao.observeByUser(userId).map { list ->
            list.map { Note(it.noteId, it.userId, it.mediaId, it.content, it.createdAt, it.updatedAt, it.isPinned) }
        }

    override fun observeNotesForMedia(userId: Int, mediaId: Int) =
        dao.observeByMedia(userId, mediaId).map { list ->
            list.map { Note(it.noteId, it.userId, it.mediaId, it.content, it.createdAt, it.updatedAt, it.isPinned) }
        }

    override suspend fun saveNote(note: Note) =
        dao.upsert(NoteEntity(note.noteId, note.userId, note.mediaId, note.content, note.createdAt, note.updatedAt, note.isPinned))

    override suspend fun deleteNote(noteId: String) = dao.delete(noteId)
}

// ─── AnalyticsRepository ───────────────────────────────────────────────────────

@Singleton
class AnalyticsRepositoryImpl @Inject constructor(
    private val playbackDao: PlaybackEventDao,
    private val genreDao: GenrePreferenceDao,
    private val mediaDao: MediaItemDao
) : AnalyticsRepository {

    override suspend fun recordPlaybackEvent(event: PlaybackEvent) {
        playbackDao.insert(PlaybackEventEntity(
            mediaId = event.mediaId, userId = event.userId,
            eventType = event.eventType.name,
            positionSeconds = event.positionSeconds,
            totalWatchedSeconds = event.positionSeconds.toLong(),
            timestamp = event.timestamp
        ))
        // Update genre preferences
        val media = mediaDao.getById(event.mediaId) ?: return
        media.genres.forEachIndexed { i, genre ->
            genreDao.increment(event.userId, i, media.runtimeMinutes.toLong())
        }
    }

    override suspend fun getWatchedGenreVectors(userId: Int): List<GenrePreference> =
        genreDao.getByUser(userId).map {
            GenrePreference(it.genreId, it.genreName, it.userId, it.watchCount, it.totalMinutesWatched)
        }

    override suspend fun getTopWatchedMedia(userId: Int): List<Pair<Int, Long>> =
        playbackDao.getTopWatchedMedia(userId).map { Pair(it.mediaId, it.totalSeconds) }

    override suspend fun getTotalPlaybackTime(): Long =
        mediaDao.getTotalWatchStats()?.totalMinutes ?: 0L
}

// ─── SettingsRepository ────────────────────────────────────────────────────────

private val KEY_FIRST_RUN      = booleanPreferencesKey("first_run")
private val KEY_ACTIVE_USER    = intPreferencesKey("active_user_id")
private val KEY_THEME          = stringPreferencesKey("theme_key")
private val KEY_AUTOPLAY       = stringPreferencesKey("autoplay_mode")
private val KEY_BIOMETRIC      = booleanPreferencesKey("biometric_enabled")
private val KEY_NOTIFICATIONS  = booleanPreferencesKey("notifications_enabled")

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<androidx.datastore.preferences.core.Preferences>
) : SettingsRepository {

    override fun observeSettings(): Flow<AppSettings> = dataStore.data.map { prefs ->
        AppSettings(
            themeKey = prefs[KEY_THEME] ?: "cosmic_purple",
            autoPlayMode = AutoPlayMode.entries.find { it.key == prefs[KEY_AUTOPLAY] } ?: AutoPlayMode.ASK,
            biometricEnabled = prefs[KEY_BIOMETRIC] ?: true,
            notificationsEnabled = prefs[KEY_NOTIFICATIONS] ?: true
        )
    }

    override suspend fun updateTheme(themeKey: String) {
        dataStore.edit { it[KEY_THEME] = themeKey }
    }

    override suspend fun updateAutoPlayMode(mode: AutoPlayMode) {
        dataStore.edit { it[KEY_AUTOPLAY] = mode.key }
    }

    override suspend fun updateBiometricEnabled(enabled: Boolean) {
        dataStore.edit { it[KEY_BIOMETRIC] = enabled }
    }

    override suspend fun isFirstRun(): Boolean {
        val prefs = dataStore.data.first()
        return prefs[KEY_FIRST_RUN] != false
    }

    override suspend fun setFirstRunComplete() {
        dataStore.edit { it[KEY_FIRST_RUN] = false }
    }

    override suspend fun getActiveUserId(): Int =
        dataStore.data.first()[KEY_ACTIVE_USER] ?: -1

    override suspend fun setActiveUserId(id: Int) {
        dataStore.edit { it[KEY_ACTIVE_USER] = id }
    }
}
