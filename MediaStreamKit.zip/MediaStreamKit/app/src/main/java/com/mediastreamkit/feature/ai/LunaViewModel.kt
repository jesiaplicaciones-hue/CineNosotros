package com.mediastreamkit.feature.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.BuildConfig
import com.mediastreamkit.core.domain.model.LunaMessage
import com.mediastreamkit.core.domain.model.LunaToolCall
import com.mediastreamkit.core.domain.model.LunaToolName
import com.mediastreamkit.core.domain.repository.AnalyticsRepository
import com.mediastreamkit.core.domain.repository.SettingsRepository
import com.mediastreamkit.core.domain.repository.SharedListRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.UUID
import javax.inject.Inject

data class LunaUiState(
    val messages: List<LunaMessage> = emptyList(),
    val inputText: String = "",
    val isThinking: Boolean = false,
    val lastToolAction: String? = null,
    val error: String? = null
)

// ─── Tool definitions sent to Claude API ──────────────────────────────────────
private val LUNA_TOOLS = """
[
  {
    "name": "add_to_shared_list",
    "description": "Agrega una película o serie a la lista compartida de ambos usuarios por su ID de TMDB.",
    "input_schema": {
      "type": "object",
      "properties": {
        "movie_id": { "type": "integer", "description": "ID de TMDB del título a agregar" }
      },
      "required": ["movie_id"]
    }
  },
  {
    "name": "filter_catalog_by_genre",
    "description": "Filtra el catálogo local por ID de género de TMDB y retorna los títulos encontrados.",
    "input_schema": {
      "type": "object",
      "properties": {
        "genre_id": { "type": "integer", "description": "ID del género TMDB (ej: 28=Acción, 35=Comedia)" }
      },
      "required": ["genre_id"]
    }
  },
  {
    "name": "get_uncompleted_sagas",
    "description": "Retorna las sagas o colecciones de películas que están en la lista compartida pero no han sido completadas.",
    "input_schema": {
      "type": "object",
      "properties": {},
      "required": []
    }
  },
  {
    "name": "get_user_history",
    "description": "Obtiene el historial de reproducción de ambos usuarios para análisis de preferencias cruzadas. NO contiene mensajes de chat privados.",
    "input_schema": {
      "type": "object",
      "properties": {
        "user_id": { "type": "integer", "description": "0 para usuario 1, 1 para usuario 2, -1 para ambos" }
      },
      "required": ["user_id"]
    }
  },
  {
    "name": "analyze_cross_preferences",
    "description": "Analiza las preferencias cruzadas de ambos usuarios y genera recomendaciones correlacionadas.",
    "input_schema": {
      "type": "object",
      "properties": {},
      "required": []
    }
  }
]
""".trimIndent()

private val LUNA_SYSTEM_PROMPT = """
Eres Luna, una asistente de IA especializada en análisis de preferencias cinematográficas y recomendaciones personalizadas para dos usuarios en la plataforma MediaStreamKit.

RESTRICCIONES ABSOLUTAS (NO NEGOCIABLES):
1. NUNCA tienes acceso ni leerás mensajes de chat privados entre los usuarios (messages_table, contextual_messages). Tu único acceso a datos es a través de las herramientas definidas que consultan playback_history_table.
2. Siempre responde en español.
3. Cuando uses herramientas, explica brevemente al usuario lo que estás haciendo.
4. Tus recomendaciones deben basarse EXCLUSIVAMENTE en datos de historial de reproducción, nunca en conversaciones privadas.

CAPACIDADES:
- Analizar patrones de visualización de ambos usuarios
- Recomendar contenido basado en intersección de preferencias
- Gestionar la lista compartida (agregar, filtrar)
- Identificar sagas incompletas
- Generar reportes de afinidad cruzada en formato JSON estructurado

Cuando generes recomendaciones, incluye siempre un campo JSON con:
{"reasoning": "...", "shared_genres": [...], "recommended_ids": [...], "confidence": 0.0-1.0}
""".trimIndent()

@HiltViewModel
class LunaViewModel @Inject constructor(
    private val analyticsRepository: AnalyticsRepository,
    private val sharedListRepository: SharedListRepository,
    private val settingsRepository: SettingsRepository,
    private val okHttpClient: OkHttpClient,
    private val json: Json
) : ViewModel() {

    private val _state = MutableStateFlow(LunaUiState())
    val state: StateFlow<LunaUiState> = _state.asStateFlow()

    private val conversationHistory = mutableListOf<JsonObject>()

    fun onInputChange(text: String) { _state.update { it.copy(inputText = text) } }

    fun sendMessage() {
        val userText = _state.value.inputText.trim()
        if (userText.isBlank()) return

        val userMsg = LunaMessage(
            id = UUID.randomUUID().toString(),
            role = "user",
            content = userText,
            timestamp = System.currentTimeMillis()
        )
        _state.update { it.copy(
            messages = it.messages + userMsg,
            inputText = "",
            isThinking = true,
            error = null
        ) }

        conversationHistory.add(buildJsonObject {
            put("role", "user")
            put("content", userText)
        })

        viewModelScope.launch {
            callClaudeApi()
        }
    }

    private suspend fun callClaudeApi() {
        try {
            val requestBody = buildJsonObject {
                put("model", "claude-sonnet-4-6")
                put("max_tokens", 2048)
                put("system", LUNA_SYSTEM_PROMPT)
                putJsonArray("tools") {
                    json.parseToJsonElement(LUNA_TOOLS).jsonArray.forEach { add(it) }
                }
                putJsonArray("messages") {
                    conversationHistory.forEach { add(it) }
                }
            }.toString()

            val request = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .post(requestBody.toRequestBody("application/json".toMediaType()))
                .addHeader("x-api-key", BuildConfig.ANTHROPIC_API_KEY)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .build()

            val response = okHttpClient.newCall(request).execute()
            val body = response.body?.string() ?: throw Exception("Empty response")

            if (!response.isSuccessful) throw Exception("API error ${response.code}: $body")

            processApiResponse(body)

        } catch (e: Exception) {
            _state.update { it.copy(
                isThinking = false,
                error = "Error de Luna: ${e.message}"
            ) }
        }
    }

    private suspend fun processApiResponse(responseBody: String) {
        val obj = json.parseToJsonElement(responseBody).jsonObject
        val stopReason = obj["stop_reason"]?.jsonPrimitive?.content
        val content = obj["content"]?.jsonArray ?: return

        val toolCalls = mutableListOf<LunaToolCall>()
        var textResponse = ""

        content.forEach { block ->
            val blockObj = block.jsonObject
            when (blockObj["type"]?.jsonPrimitive?.content) {
                "text" -> textResponse = blockObj["text"]?.jsonPrimitive?.content ?: ""
                "tool_use" -> {
                    val toolName = blockObj["name"]?.jsonPrimitive?.content ?: return@forEach
                    val toolInput = blockObj["input"]?.jsonObject ?: buildJsonObject {}
                    val args = toolInput.entries.associate { (k, v) ->
                        k to (v.jsonPrimitive.contentOrNull ?: v.toString() as Any)
                    }
                    toolCalls.add(LunaToolCall(name = toolName, arguments = args))
                }
            }
        }

        // Add assistant turn to history
        conversationHistory.add(buildJsonObject {
            put("role", "assistant")
            putJsonArray("content") {
                content.forEach { add(it) }
            }
        })

        if (stopReason == "tool_use" && toolCalls.isNotEmpty()) {
            // Execute tools and feed results back
            val toolResults = toolCalls.map { call ->
                val result = dispatchToolCall(call)
                _state.update { it.copy(lastToolAction = "Ejecutando: ${call.name}") }
                buildJsonObject {
                    put("type", "tool_result")
                    put("tool_use_id", call.name)
                    put("content", result)
                }
            }

            // Add tool results to history
            conversationHistory.add(buildJsonObject {
                put("role", "user")
                putJsonArray("content") { toolResults.forEach { add(it) } }
            })

            // Continue the conversation
            callClaudeApi()
        } else {
            // Final text response
            if (textResponse.isNotBlank()) {
                val lunaMsg = LunaMessage(
                    id = UUID.randomUUID().toString(),
                    role = "assistant",
                    content = textResponse,
                    timestamp = System.currentTimeMillis(),
                    toolCalls = toolCalls.ifEmpty { null }
                )
                _state.update { it.copy(
                    messages = it.messages + lunaMsg,
                    isThinking = false,
                    lastToolAction = null
                ) }
            }
        }
    }

    private suspend fun dispatchToolCall(call: LunaToolCall): String {
        return try {
            when (call.name) {
                LunaToolName.ADD_TO_SHARED_LIST.fnName -> {
                    val movieId = (call.arguments["movie_id"] as? String)?.toIntOrNull() ?: return "Error: movie_id inválido"
                    val userId = settingsRepository.getActiveUserId()
                    sharedListRepository.addToSharedList(movieId, userId)
                    """{"success": true, "message": "Título $movieId agregado a la lista compartida"}"""
                }
                LunaToolName.FILTER_CATALOG_BY_GENRE.fnName -> {
                    val genreId = (call.arguments["genre_id"] as? String)?.toIntOrNull() ?: return "Error: genre_id inválido"
                    val items = sharedListRepository.filterByGenre(genreId)
                    """{"count": ${items.size}, "titles": ${items.take(10).map { it.title }}}"""
                }
                LunaToolName.GET_UNCOMPLETED_SAGAS.fnName -> {
                    val sagas = sharedListRepository.getUncompletedSagas()
                    val grouped = sagas.groupBy { it.sagaName ?: "Sin saga" }
                    """{"sagas": ${grouped.keys.toList()}, "total_incomplete": ${grouped.size}}"""
                }
                LunaToolName.GET_USER_HISTORY.fnName -> {
                    val userId = (call.arguments["user_id"] as? String)?.toIntOrNull() ?: -1
                    val usersToQuery = if (userId == -1) listOf(0, 1) else listOf(userId)
                    val result = usersToQuery.associate { uid ->
                        val genres = analyticsRepository.getWatchedGenreVectors(uid)
                        val topMedia = analyticsRepository.getTopWatchedMedia(uid)
                        uid.toString() to mapOf(
                            "top_genres" to genres.take(5).map { it.genreName },
                            "top_media_ids" to topMedia.take(10).map { it.first }
                        )
                    }
                    json.encodeToString(kotlinx.serialization.json.JsonObject.serializer(),
                        buildJsonObject {
                            result.forEach { (uid, data) ->
                                put(uid, buildJsonObject {
                                    putJsonArray("top_genres") {
                                        @Suppress("UNCHECKED_CAST")
                                        (data["top_genres"] as List<String>).forEach { add(it) }
                                    }
                                    putJsonArray("top_media_ids") {
                                        @Suppress("UNCHECKED_CAST")
                                        (data["top_media_ids"] as List<Int>).forEach { add(it) }
                                    }
                                })
                            }
                        }
                    )
                }
                LunaToolName.ANALYZE_CROSS_PREFERENCES.fnName -> {
                    val user1Genres = analyticsRepository.getWatchedGenreVectors(0)
                    val user2Genres = analyticsRepository.getWatchedGenreVectors(1)
                    val shared = user1Genres.map { it.genreName }
                        .intersect(user2Genres.map { it.genreName }.toSet())
                    val totalTime = analyticsRepository.getTotalPlaybackTime()
                    """{"shared_genres": $shared, "total_watch_minutes": $totalTime, "users_analyzed": 2}"""
                }
                else -> """{"error": "Herramienta desconocida: ${call.name}"}"""
            }
        } catch (e: Exception) {
            """{"error": "${e.message}"}"""
        }
    }
}
