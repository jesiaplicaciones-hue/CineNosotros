package com.mediastreamkit.feature.sync

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.data.remote.websocket.MskWebSocketClient
import com.mediastreamkit.core.data.remote.websocket.WsEvent
import com.mediastreamkit.core.domain.model.PlaybackState
import com.mediastreamkit.core.domain.repository.AnalyticsRepository
import com.mediastreamkit.core.domain.model.PlaybackEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import timber.log.Timber
import javax.inject.Inject
import kotlin.math.abs

data class SyncUiState(
    val roomCode: String = "",
    val isRoomReady: Boolean = false,
    val isCreatingRoom: Boolean = false,
    val playbackState: PlaybackState = PlaybackState.PAUSE,
    val currentPositionSec: Float = 0f,
    val mediaId: Int = -1,
    val networkLost: Boolean = false,
    val rttMs: Long = 0L,
    val error: String? = null
)

private const val SYNC_THRESHOLD_MS = 500L

@HiltViewModel
class SyncViewModel @Inject constructor(
    private val wsClient: MskWebSocketClient,
    private val analyticsRepository: AnalyticsRepository,
    private val json: Json
) : ViewModel() {

    private val _state = MutableStateFlow(SyncUiState())
    val state: StateFlow<SyncUiState> = _state.asStateFlow()

    // Callback to player: seekTo seconds
    private var seekCallback: ((Float) -> Unit)? = null
    private var forcePlayCallback: ((Boolean) -> Unit)? = null

    fun attachPlayerCallbacks(
        onSeek: (Float) -> Unit,
        onPlayPause: (Boolean) -> Unit
    ) {
        seekCallback  = onSeek
        forcePlayCallback = onPlayPause
    }

    init { observeWsEvents() }

    private fun observeWsEvents() {
        viewModelScope.launch {
            wsClient.events.collect { event ->
                when (event) {
                    is WsEvent.RoomCreated ->
                        _state.update { it.copy(roomCode = event.code, isCreatingRoom = false) }

                    is WsEvent.RoomReady ->
                        _state.update { it.copy(isRoomReady = true) }

                    is WsEvent.PlaybackSync -> handleSyncPayload(event.payload)

                    is WsEvent.NetworkLost -> {
                        _state.update { it.copy(networkLost = true, playbackState = PlaybackState.PAUSE) }
                        forcePlayCallback?.invoke(false)
                    }

                    else -> {}
                }
            }
        }
    }

    /**
     * Cristian's Algorithm — RTT compensation.
     * rtt = (localReceiveTime - localSendTime) / 2
     * Adjust remote timestamp by half RTT to compensate for network delay.
     */
    private fun handleSyncPayload(raw: String) {
        try {
            val localReceive = System.currentTimeMillis()
            val obj = json.parseToJsonElement(raw).jsonObject
            val remoteState   = obj["playbackState"]?.jsonPrimitive?.content ?: return
            val remoteTs      = obj["timestampSeconds"]?.jsonPrimitive?.float ?: return
            val remoteEpoch   = obj["clientEpochTime"]?.jsonPrimitive?.long ?: return

            val rtt = localReceive - remoteEpoch
            val compensatedTs = remoteTs + (rtt / 1000f / 2f)

            val localTs = _state.value.currentPositionSec
            val diff    = abs(compensatedTs - localTs) * 1000  // ms

            _state.update { it.copy(rttMs = rtt) }

            when (remoteState) {
                "PLAY"  -> {
                    if (diff > SYNC_THRESHOLD_MS) seekCallback?.invoke(compensatedTs)
                    forcePlayCallback?.invoke(true)
                    _state.update { it.copy(playbackState = PlaybackState.PLAY) }
                }
                "PAUSE" -> {
                    forcePlayCallback?.invoke(false)
                    _state.update { it.copy(playbackState = PlaybackState.PAUSE) }
                }
                "SEEK"  -> {
                    seekCallback?.invoke(compensatedTs)
                    _state.update { it.copy(currentPositionSec = compensatedTs) }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Sync payload parse error")
        }
    }

    fun createRoom(mediaId: Int) {
        _state.update { it.copy(isCreatingRoom = true, mediaId = mediaId) }
        wsClient.createRoom(mediaId)
    }

    fun joinRoom(code: String) {
        _state.update { it.copy(roomCode = code) }
        wsClient.joinRoom(code)
    }

    fun onLocalPlay(positionSec: Float) {
        val s = _state.value
        if (!s.isRoomReady) return
        _state.update { it.copy(playbackState = PlaybackState.PLAY, currentPositionSec = positionSec) }
        wsClient.sendPlaybackState("PLAY", positionSec, s.roomCode, s.mediaId)
        recordEvent(PlaybackState.PLAY, positionSec)
    }

    fun onLocalPause(positionSec: Float) {
        val s = _state.value
        if (!s.isRoomReady) return
        _state.update { it.copy(playbackState = PlaybackState.PAUSE, currentPositionSec = positionSec) }
        wsClient.sendPlaybackState("PAUSE", positionSec, s.roomCode, s.mediaId)
        recordEvent(PlaybackState.PAUSE, positionSec)
    }

    fun onLocalSeek(positionSec: Float) {
        val s = _state.value
        if (!s.isRoomReady) return
        _state.update { it.copy(currentPositionSec = positionSec) }
        wsClient.sendPlaybackState("SEEK", positionSec, s.roomCode, s.mediaId)
    }

    fun onMediaEnded(userId: Int) {
        recordEvent(PlaybackState.ENDED, _state.value.currentPositionSec, userId)
    }

    fun dismissNetworkLostDialog() {
        _state.update { it.copy(networkLost = false) }
    }

    private fun recordEvent(
        state: PlaybackState,
        positionSec: Float,
        userId: Int = 0
    ) {
        viewModelScope.launch {
            analyticsRepository.recordPlaybackEvent(
                PlaybackEvent(
                    mediaId = _state.value.mediaId,
                    userId = userId,
                    eventType = state,
                    positionSeconds = positionSec,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }
}
