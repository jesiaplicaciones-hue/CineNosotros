package com.mediastreamkit.core.security

import java.security.MessageDigest
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PasswordHasher @Inject constructor() {

    private val random = SecureRandom()

    /** Generates a random 16-byte salt encoded as hex */
    fun generateSalt(): String {
        val salt = ByteArray(16)
        random.nextBytes(salt)
        return salt.joinToString("") { "%02x".format(it) }
    }

    /**
     * PBKDF2-like SHA-256 stretch: 10,000 rounds.
     * Returns hex(sha256^10000(salt + password)).
     * For production, replace with BCrypt via a JVM provider.
     */
    fun hash(password: String, salt: String): String {
        var digest = (salt + password).toByteArray(Charsets.UTF_8)
        val md = MessageDigest.getInstance("SHA-256")
        repeat(10_000) { digest = md.digest(digest) }
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verify(password: String, salt: String, storedHash: String): Boolean =
        hash(password, salt) == storedHash

    /** Combines salt+hash into a single storable string */
    fun encode(password: String): String {
        val salt = generateSalt()
        return "$salt:${hash(password, salt)}"
    }

    /** Verifies against a combined salt:hash string */
    fun verifyEncoded(password: String, encoded: String): Boolean {
        val parts = encoded.split(":")
        if (parts.size != 2) return false
        return verify(password, parts[0], parts[1])
    }
}
