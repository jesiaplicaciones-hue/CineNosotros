package com.mediastreamkit.feature.call

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.network.WebRtcManager
import com.mediastreamkit.core.network.WebRtcState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CallViewModel @Inject constructor(
    private val webRtcManager: WebRtcManager
) : ViewModel() {
    val state: StateFlow<WebRtcState> = webRtcManager.state

    fun startAudioCall(context: android.content.Context) {
        viewModelScope.launch { webRtcManager.startCall(context, withVideo = false) }
    }

    fun startVideoCall(context: android.content.Context) {
        viewModelScope.launch { webRtcManager.startCall(context, withVideo = true) }
    }

    fun toggleAudio() = webRtcManager.toggleAudio()
    fun toggleVideo() = webRtcManager.toggleVideo()
    fun endCall()     = webRtcManager.endCall()
}

@Composable
fun CallScreen(
    onBack: () -> Unit,
    viewModel: CallViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        // Remote video placeholder (SurfaceView would be injected here)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0D0D0D)),
            contentAlignment = Alignment.Center
        ) {
            if (!state.isCallActive) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.VideoCall, null,
                        modifier = Modifier.size(72.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                    Spacer(Modifier.height(16.dp))
                    Text("Sin llamada activa", color = Color.White,
                        style = MaterialTheme.typography.titleMedium)
                }
            } else {
                Text("📡 Llamada activa — P2P WebRTC",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Local video PiP placeholder
        if (state.isVideoEnabled && state.isCallActive) {
            Box(
                modifier = Modifier
                    .size(width = 120.dp, height = 160.dp)
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .clip(MaterialTheme.shapes.medium)
                    .background(Color(0xFF1A1A1A))
            ) {
                Text("LOCAL", color = Color.White.copy(alpha = 0.4f),
                    modifier = Modifier.align(Alignment.Center),
                    style = MaterialTheme.typography.labelSmall)
            }
        }

        // Controls bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.5f))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (!state.isCallActive) {
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    // Audio call
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatingActionButton(
                            onClick = { viewModel.startAudioCall(context) },
                            containerColor = MaterialTheme.colorScheme.primary
                        ) {
                            Icon(Icons.Default.Call, "Llamada de audio",
                                tint = Color.White)
                        }
                        Text("Audio", color = Color.White,
                            style = MaterialTheme.typography.labelSmall)
                    }
                    // Video call
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatingActionButton(
                            onClick = { viewModel.startVideoCall(context) },
                            containerColor = MaterialTheme.colorScheme.secondary
                        ) {
                            Icon(Icons.Default.Videocam, "Videollamada",
                                tint = Color.White)
                        }
                        Text("Video", color = Color.White,
                            style = MaterialTheme.typography.labelSmall)
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    // Mute
                    FilledTonalIconButton(
                        onClick = viewModel::toggleAudio,
                        modifier = Modifier.size(56.dp),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = if (state.isAudioEnabled)
                                Color.White.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.6f)
                        )
                    ) {
                        Icon(
                            if (state.isAudioEnabled) Icons.Default.Mic else Icons.Default.MicOff,
                            "Micrófono", tint = Color.White
                        )
                    }
                    // Camera
                    FilledTonalIconButton(
                        onClick = viewModel::toggleVideo,
                        modifier = Modifier.size(56.dp),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = if (state.isVideoEnabled)
                                Color.White.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.5f)
                        )
                    ) {
                        Icon(
                            if (state.isVideoEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            "Cámara", tint = Color.White
                        )
                    }
                    // End call
                    FloatingActionButton(
                        onClick = viewModel::endCall,
                        containerColor = Color.Red,
                        modifier = Modifier.size(56.dp)
                    ) {
                        Icon(Icons.Default.CallEnd, "Terminar llamada",
                            tint = Color.White)
                    }
                }
            }
        }

        // Back button
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
        ) {
            Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White)
        }
    }
}
