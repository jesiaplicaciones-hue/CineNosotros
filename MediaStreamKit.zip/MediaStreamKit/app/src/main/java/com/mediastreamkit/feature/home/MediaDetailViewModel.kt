package com.mediastreamkit.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkManager
import com.mediastreamkit.core.data.local.dao.DownloadQueueDao
import com.mediastreamkit.core.data.local.entities.DownloadQueueEntity
import com.mediastreamkit.core.domain.model.MediaItem
import com.mediastreamkit.core.domain.model.Note
import com.mediastreamkit.core.domain.repository.*
import com.mediastreamkit.core.service.DownloadWorker
import com.mediastreamkit.core.utils.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class MediaDetailUiState(
    val media: MediaItem? = null,
    val isInSharedList: Boolean = false,
    val isDownloading: Boolean = false,
    val downloadProgress: Int = 0,
    val recommendations: List<MediaItem> = emptyList(),
    val notes: List<Note> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class MediaDetailViewModel @Inject constructor(
    private val mediaRepository: MediaRepository,
    private val sharedListRepository: SharedListRepository,
    private val noteRepository: NoteRepository,
    private val settingsRepository: SettingsRepository,
    private val downloadQueueDao: DownloadQueueDao,
    private val workManager: WorkManager
) : ViewModel() {

    private val _state = MutableStateFlow(MediaDetailUiState())
    val state: StateFlow<MediaDetailUiState> = _state.asStateFlow()

    fun loadMedia(mediaId: Int) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val media = mediaRepository.getById(mediaId)
                    ?: return@launch _state.update {
                        it.copy(isLoading = false, error = "Contenido no encontrado")
                    }

                val inSharedList = sharedListRepository.exists(mediaId)

                // Observe notes for this media
                val userId = settingsRepository.getActiveUserId()
                noteRepository.observeNotesForMedia(userId, mediaId)
                    .collect { notes ->
                        _state.update { it.copy(notes = notes) }
                    }

                // Load recommendations asynchronously
                val recs = when (val result = mediaRepository.getRecommendations(mediaId)) {
                    is Result.Success -> result.data
                    else              -> emptyList()
                }

                _state.update {
                    it.copy(
                        media         = media,
                        isInSharedList = inSharedList,
                        recommendations = recs,
                        isLoading     = false
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    fun toggleSharedList() {
        val media = _state.value.media ?: return
        viewModelScope.launch {
            val userId = settingsRepository.getActiveUserId()
            if (_state.value.isInSharedList) {
                sharedListRepository.removeFromSharedList(media.id)
                _state.update { it.copy(isInSharedList = false) }
            } else {
                sharedListRepository.addToSharedList(media.id, userId)
                _state.update { it.copy(isInSharedList = true) }
            }
        }
    }

    fun enqueueDownload(streamUrl: String) {
        val media = _state.value.media ?: return
        viewModelScope.launch {
            downloadQueueDao.enqueue(DownloadQueueEntity(
                mediaId    = media.id,
                title      = media.title,
                streamUrl  = streamUrl,
                status     = "PENDING",
                workerId   = null
            ))
            val request = DownloadWorker.buildRequest(media.id, media.title, streamUrl)
            workManager.enqueue(request)
            _state.update { it.copy(isDownloading = true) }
        }
    }
}
