package com.mediastreamkit.feature.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.random.Random

data class SplashUiState(
    val phrase: String = "",
    val isReady: Boolean = false,
    val navigateTo: SplashDestination = SplashDestination.NONE
)

enum class SplashDestination { NONE, SETUP, LOGIN }

private val MOTIVATIONAL_PHRASES = listOf(
    "El cine es un espejo que refleja el alma humana.",
    "Cada fotograma es una ventana a otro mundo.",
    "Sincronizando momentos, conectando corazones.",
    "La magia comienza cuando dos historias se unen.",
    "MediaStreamKit — Tu experiencia, perfectamente sincronizada.",
    "Dos personas. Un ritmo. Infinitas historias.",
    "El tiempo compartido es el tiempo bien vivido.",
    "La distancia desaparece cuando la historia comienza.",
    "Cada escena es mejor cuando la ves junto a alguien.",
    "Tu universo privado de entretenimiento compartido."
)

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SplashUiState())
    val uiState: StateFlow<SplashUiState> = _uiState.asStateFlow()

    init {
        initialize()
    }

    private fun initialize() {
        viewModelScope.launch {
            // Pick random phrase
            val phrase = MOTIVATIONAL_PHRASES[Random.nextInt(MOTIVATIONAL_PHRASES.size)]
            _uiState.update { it.copy(phrase = phrase) }

            // Parallel: check first-run while phrase displays
            val isFirstRun = settingsRepository.isFirstRun()
            delay(2_800)   // let fade-in/fade-out animation complete

            _uiState.update { it.copy(
                isReady = true,
                navigateTo = if (isFirstRun) SplashDestination.SETUP else SplashDestination.LOGIN
            ) }
        }
    }
}
