package com.mediastreamkit.core.data.local.dao

import androidx.room.*
import com.mediastreamkit.core.data.local.entities.*
import kotlinx.coroutines.flow.Flow

// ─── UserProfileDao ───────────────────────────────────────────────────────────

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profiles ORDER BY id ASC")
    fun observeAll(): Flow<List<UserProfileEntity>>

    @Query("SELECT * FROM user_profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): UserProfileEntity?

    @Query("SELECT COUNT(*) FROM user_profiles")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: UserProfileEntity)

    @Update
    suspend fun update(profile: UserProfileEntity)

    @Query("DELETE FROM user_profiles WHERE id = :id")
    suspend fun deleteById(id: Int)
}

// ─── MediaItemDao ─────────────────────────────────────────────────────────────

@Dao
interface MediaItemDao {
    @Query("SELECT * FROM media_items ORDER BY title ASC")
    fun observeAll(): Flow<List<MediaItemEntity>>

    @Query("SELECT * FROM media_items WHERE category = :category ORDER BY title ASC")
    fun observeByCategory(category: String): Flow<List<MediaItemEntity>>

    @Query("SELECT * FROM media_items WHERE isWatched = 0 AND watchedProgress > 0 ORDER BY cachedAt DESC LIMIT 20")
    fun observeContinueWatching(): Flow<List<MediaItemEntity>>

    @Query("SELECT * FROM media_items WHERE isWatched = 1 ORDER BY cachedAt DESC LIMIT 50")
    fun observeHistory(): Flow<List<MediaItemEntity>>

    @Query("SELECT * FROM media_items WHERE isDownloaded = 1 ORDER BY title ASC")
    fun observeDownloaded(): Flow<List<MediaItemEntity>>

    @Query("SELECT * FROM media_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): MediaItemEntity?

    @Query("SELECT * FROM media_items WHERE sagaId = :sagaId ORDER BY releaseDate ASC")
    suspend fun getBySagaId(sagaId: Int): List<MediaItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<MediaItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: MediaItemEntity)

    @Query("UPDATE media_items SET isWatched = :isWatched, watchedProgress = :progress WHERE id = :id")
    suspend fun updateWatchedState(id: Int, isWatched: Boolean, progress: Float)

    @Query("UPDATE media_items SET isDownloaded = :downloaded, downloadPath = :path WHERE id = :id")
    suspend fun updateDownloadState(id: Int, downloaded: Boolean, path: String?)

    @Query("DELETE FROM media_items WHERE isDownloaded = 0 AND cachedAt < :olderThan")
    suspend fun evictOldCache(olderThan: Long)

    // Analytics queries
    @Query("""
        SELECT COUNT(*) as watchCount, SUM(runtimeMinutes) as totalMinutes 
        FROM media_items m 
        WHERE m.isWatched = 1
    """)
    suspend fun getTotalWatchStats(): WatchStats?
}

data class WatchStats(val watchCount: Int, val totalMinutes: Long)

// ─── ChatMessageDao ───────────────────────────────────────────────────────────

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE mediaId IS NULL ORDER BY timestamp ASC")
    fun observeGeneralChat(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM contextual_messages WHERE media_id = :mediaId ORDER BY timestamp ASC")
    fun observeContextualChat(mediaId: Int): Flow<List<ContextualMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertContextualMessage(message: ContextualMessageEntity)

    @Query("UPDATE chat_messages SET isRead = 1 WHERE senderId != :myUserId AND isRead = 0")
    suspend fun markAllRead(myUserId: Int)

    @Query("SELECT COUNT(*) FROM chat_messages WHERE isRead = 0 AND senderId != :myUserId")
    fun observeUnreadCount(myUserId: Int): Flow<Int>

    @Query("DELETE FROM chat_messages WHERE timestamp < :before")
    suspend fun purgeOlderThan(before: Long)
}

// ─── PlaybackEventDao ─────────────────────────────────────────────────────────

@Dao
interface PlaybackEventDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(event: PlaybackEventEntity)

    @Query("""
        SELECT * FROM playback_history_table 
        WHERE userId = :userId 
        ORDER BY timestamp DESC 
        LIMIT :limit
    """)
    suspend fun getUserHistory(userId: Int, limit: Int = 100): List<PlaybackEventEntity>

    @Query("""
        SELECT mediaId, SUM(totalWatchedSeconds) as totalSeconds 
        FROM playback_history_table 
        WHERE userId = :userId 
        GROUP BY mediaId 
        ORDER BY totalSeconds DESC 
        LIMIT 20
    """)
    suspend fun getTopWatchedMedia(userId: Int): List<WatchTimeRow>

    @Query("""
        SELECT COUNT(*) as events, mediaId 
        FROM playback_history_table 
        WHERE eventType = 'ENDED' AND mediaId = :mediaId
    """)
    suspend fun getDropOffData(mediaId: Int): DropOffRow?

    // Used by Luna analytics ONLY — no messages_table access
    @Query("""
        SELECT ph.mediaId, m.genres 
        FROM playback_history_table ph 
        JOIN media_items m ON ph.mediaId = m.id 
        WHERE ph.userId = :userId 
        GROUP BY ph.mediaId
    """)
    suspend fun getWatchedGenreVectors(userId: Int): List<GenreVector>
}

data class WatchTimeRow(val mediaId: Int, val totalSeconds: Long)
data class DropOffRow(val events: Int, val mediaId: Int)
data class GenreVector(val mediaId: Int, val genres: String)

// ─── SharedListDao ────────────────────────────────────────────────────────────

@Dao
interface SharedListDao {
    @Query("""
        SELECT m.* FROM media_items m 
        INNER JOIN shared_list sl ON m.id = sl.mediaId 
        ORDER BY sl.addedAt DESC
    """)
    fun observeSharedList(): Flow<List<MediaItemEntity>>

    @Query("""
        SELECT m.* FROM media_items m 
        INNER JOIN shared_list sl ON m.id = sl.mediaId 
        WHERE sl.isCompleted = 0 
        AND m.sagaId IS NOT NULL 
        ORDER BY m.releaseDate ASC
    """)
    suspend fun getUncompletedSagas(): List<MediaItemEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun add(entry: SharedListEntity)

    @Query("DELETE FROM shared_list WHERE mediaId = :mediaId")
    suspend fun remove(mediaId: Int)

    @Query("UPDATE shared_list SET isCompleted = 1 WHERE mediaId = :mediaId")
    suspend fun markCompleted(mediaId: Int)

    @Query("SELECT EXISTS(SELECT 1 FROM shared_list WHERE mediaId = :mediaId)")
    suspend fun exists(mediaId: Int): Boolean
}

// ─── NoteDao ──────────────────────────────────────────────────────────────────

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE userId = :userId ORDER BY isPinned DESC, updatedAt DESC")
    fun observeByUser(userId: Int): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE userId = :userId AND mediaId = :mediaId ORDER BY updatedAt DESC")
    fun observeByMedia(userId: Int, mediaId: Int): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: NoteEntity)

    @Query("DELETE FROM notes WHERE noteId = :noteId")
    suspend fun delete(noteId: String)
}

// ─── GenrePreferenceDao ───────────────────────────────────────────────────────

@Dao
interface GenrePreferenceDao {
    @Query("SELECT * FROM genre_preferences WHERE userId = :userId ORDER BY watchCount DESC")
    suspend fun getByUser(userId: Int): List<GenrePreferenceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(prefs: List<GenrePreferenceEntity>)

    @Query("""
        UPDATE genre_preferences 
        SET watchCount = watchCount + 1, totalMinutesWatched = totalMinutesWatched + :minutes 
        WHERE userId = :userId AND genreId = :genreId
    """)
    suspend fun increment(userId: Int, genreId: Int, minutes: Long)
}

// ─── DownloadQueueDao ─────────────────────────────────────────────────────────

@Dao
interface DownloadQueueDao {
    @Query("SELECT * FROM download_queue ORDER BY enqueuedAt ASC")
    fun observeQueue(): Flow<List<DownloadQueueEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(item: DownloadQueueEntity)

    @Query("UPDATE download_queue SET status = :status, progressPercent = :progress WHERE mediaId = :mediaId")
    suspend fun updateProgress(mediaId: Int, status: String, progress: Int)

    @Query("DELETE FROM download_queue WHERE mediaId = :mediaId")
    suspend fun remove(mediaId: Int)
}
