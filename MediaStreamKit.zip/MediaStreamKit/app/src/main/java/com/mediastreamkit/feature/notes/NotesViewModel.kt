package com.mediastreamkit.feature.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.domain.model.Note
import com.mediastreamkit.core.domain.repository.NoteRepository
import com.mediastreamkit.core.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class NotesUiState(
    val notes: List<Note> = emptyList(),
    val editingNote: Note? = null,
    val draftContent: String = "",
    val userId: Int = 0
)

@HiltViewModel
class NotesViewModel @Inject constructor(
    private val noteRepository: NoteRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(NotesUiState())
    val state: StateFlow<NotesUiState> = _state.asStateFlow()

    fun initialize(mediaId: Int? = null) {
        viewModelScope.launch {
            val userId = settingsRepository.getActiveUserId()
            _state.update { it.copy(userId = userId) }
            val flow = if (mediaId != null)
                noteRepository.observeNotesForMedia(userId, mediaId)
            else
                noteRepository.observeNotes(userId)

            flow.collect { notes -> _state.update { it.copy(notes = notes) } }
        }
    }

    fun startNewNote(mediaId: Int? = null) {
        val now = System.currentTimeMillis()
        _state.update { it.copy(
            editingNote = Note(
                noteId = UUID.randomUUID().toString(),
                userId = it.userId,
                mediaId = mediaId,
                content = "",
                createdAt = now,
                updatedAt = now
            ),
            draftContent = ""
        ) }
    }

    fun editNote(note: Note) {
        _state.update { it.copy(editingNote = note, draftContent = note.content) }
    }

    fun onDraftChange(text: String) {
        _state.update { it.copy(draftContent = text) }
    }

    fun saveNote() {
        val s = _state.value
        val note = s.editingNote?.copy(
            content = s.draftContent,
            updatedAt = System.currentTimeMillis()
        ) ?: return
        viewModelScope.launch {
            noteRepository.saveNote(note)
            _state.update { it.copy(editingNote = null, draftContent = "") }
        }
    }

    fun deleteNote(noteId: String) {
        viewModelScope.launch { noteRepository.deleteNote(noteId) }
    }

    fun togglePin(note: Note) {
        viewModelScope.launch {
            noteRepository.saveNote(note.copy(isPinned = !note.isPinned,
                updatedAt = System.currentTimeMillis()))
        }
    }

    fun cancelEdit() {
        _state.update { it.copy(editingNote = null, draftContent = "") }
    }
}
