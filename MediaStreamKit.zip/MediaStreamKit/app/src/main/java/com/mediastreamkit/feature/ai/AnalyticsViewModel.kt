package com.mediastreamkit.feature.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.domain.model.AfinityReport
import com.mediastreamkit.core.domain.model.GenrePreference
import com.mediastreamkit.core.domain.repository.AnalyticsRepository
import com.mediastreamkit.core.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AnalyticsUiState(
    val isLoading: Boolean = true,
    val user1TopGenres: List<GenrePreference> = emptyList(),
    val user2TopGenres: List<GenrePreference> = emptyList(),
    val sharedGenres: List<String> = emptyList(),
    val totalMinutesUser1: Long = 0L,
    val totalMinutesUser2: Long = 0L,
    val afinityReport: AfinityReport? = null,
    val error: String? = null
)

@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    private val analyticsRepository: AnalyticsRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(AnalyticsUiState())
    val state: StateFlow<AnalyticsUiState> = _state.asStateFlow()

    init { loadAnalytics() }

    fun loadAnalytics() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            try {
                val u1Genres = analyticsRepository.getWatchedGenreVectors(0)
                val u2Genres = analyticsRepository.getWatchedGenreVectors(1)

                val u1Names = u1Genres.map { it.genreName }.toSet()
                val u2Names = u2Genres.map { it.genreName }.toSet()
                val shared  = u1Names.intersect(u2Names).toList()

                val u1Total = u1Genres.sumOf { it.totalMinutes }
                val u2Total = u2Genres.sumOf { it.totalMinutes }

                // Build a basic affinity report locally (Luna can enrich it via LLM)
                val confidence = if (shared.isEmpty()) 0f
                    else shared.size.toFloat() / maxOf(u1Names.size, u2Names.size, 1).toFloat()

                val report = AfinityReport(
                    sharedGenres       = shared,
                    recommendedMediaIds = emptyList(), // populated by Luna tool calls
                    confidenceScore    = confidence,
                    reasoning          = if (shared.isEmpty())
                        "Sin géneros compartidos detectados aún."
                    else
                        "Ambos usuarios comparten interés en: ${shared.joinToString(", ")}."
                )

                _state.update {
                    it.copy(
                        isLoading       = false,
                        user1TopGenres  = u1Genres.take(5),
                        user2TopGenres  = u2Genres.take(5),
                        sharedGenres    = shared,
                        totalMinutesUser1 = u1Total,
                        totalMinutesUser2 = u2Total,
                        afinityReport   = report
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }
}
