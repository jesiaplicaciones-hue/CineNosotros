package com.mediastreamkit.feature.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.mediastreamkit.core.domain.model.MediaItem
import com.mediastreamkit.core.utils.toTmdbImageUrl
import com.mediastreamkit.ui.theme.mskColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaDetailScreen(
    mediaId: Int,
    onBack: () -> Unit,
    onPlayClick: (MediaItem) -> Unit,
    onSyncClick: (Int) -> Unit,
    onChatClick: (Int) -> Unit,
    onNotesClick: (Int) -> Unit,
    viewModel: MediaDetailViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(mediaId) { viewModel.loadMedia(mediaId) }

    if (state.isLoading) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
        return
    }

    val media = state.media ?: run {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center) {
            Text(state.error ?: "Error", color = MaterialTheme.colorScheme.error)
        }
        return
    }

    val colors = MaterialTheme.mskColors

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // ── Backdrop ─────────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
        ) {
            AsyncImage(
                model = media.backdropPath.toTmdbImageUrl("w780"),
                contentDescription = media.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Gradient fade to background
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color.Transparent,
                            0.6f to MaterialTheme.colorScheme.background.copy(alpha = 0.5f),
                            1f to MaterialTheme.colorScheme.background
                        )
                    )
            )
            // Back button
            IconButton(
                onClick = onBack,
                modifier = Modifier.padding(16.dp).align(Alignment.TopStart)
            ) {
                Icon(Icons.Default.ArrowBack, "Volver",
                    tint = Color.White,
                    modifier = Modifier
                        .clip(MaterialTheme.shapes.small)
                        .background(Color.Black.copy(alpha = 0.4f))
                        .padding(4.dp)
                )
            }
        }

        // ── Content ───────────────────────────────────────────────────────────
        Column(
            modifier = Modifier.padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Title + metadata
            Text(media.title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground)

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (media.releaseDate.isNotBlank()) {
                    MetaChip(text = media.releaseDate.take(4))
                }
                if (media.runtimeMinutes > 0) {
                    MetaChip(text = "${media.runtimeMinutes}m")
                }
                media.genres.take(2).forEach { genre ->
                    MetaChip(text = genre)
                }
            }

            // Progress bar if in progress
            if (media.watchedProgress > 0f && !media.isWatched) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text("Progreso", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${(media.watchedProgress * 100).toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary)
                    }
                    LinearProgressIndicator(
                        progress = { media.watchedProgress },
                        modifier = Modifier.fillMaxWidth().height(4.dp)
                            .clip(MaterialTheme.shapes.small),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }

            // Action buttons row
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { onPlayClick(media) },
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (media.watchedProgress > 0f) "Continuar" else "Reproducir")
                }
                FilledTonalIconButton(
                    onClick = { viewModel.toggleSharedList() },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        if (state.isInSharedList) Icons.Default.BookmarkAdded
                        else Icons.Default.BookmarkAdd,
                        "Lista compartida",
                        tint = if (state.isInSharedList) MaterialTheme.colorScheme.primary
                               else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                FilledTonalIconButton(
                    onClick = { onSyncClick(media.id) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Default.Sync, "Sincronizar",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalIconButton(
                    onClick = { onChatClick(media.id) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Default.Chat, "Chat contextual",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalIconButton(
                    onClick = { onNotesClick(media.id) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Default.Notes, "Notas",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Download button
            if (!media.isDownloaded) {
                OutlinedButton(
                    onClick = {
                        viewModel.enqueueDownload("https://your-stream-server.com/stream/${media.id}")
                    },
                    enabled = !state.isDownloading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Download, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (state.isDownloading) "Descargando… ${state.downloadProgress}%"
                         else "Descargar para ver sin conexión")
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.DownloadDone, null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp))
                    Text("Disponible sin conexión",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary)
                }
            }

            // Overview
            if (media.overview.isNotBlank()) {
                Text("Sinopsis",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onBackground)
                Text(media.overview,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // Saga info
            media.sagaName?.let { sagaName ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Collections, null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(18.dp))
                        Text("Parte de la saga: $sagaName",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }

            // Notes preview
            if (state.notes.isNotEmpty()) {
                Text("Tus notas",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onBackground)
                state.notes.take(2).forEach { note ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(note.content,
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis)
                    }
                }
                if (state.notes.size > 2) {
                    TextButton(onClick = { onNotesClick(media.id) }) {
                        Text("Ver todas las notas (${state.notes.size})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            // Recommendations
            if (state.recommendations.isNotEmpty()) {
                Text("También te podría gustar",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onBackground)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    state.recommendations.take(3).forEach { rec ->
                        Card(
                            modifier = Modifier.width(110.dp).height(160.dp),
                            shape = MaterialTheme.shapes.medium
                        ) {
                            Box(Modifier.fillMaxSize()) {
                                AsyncImage(
                                    model = rec.posterPath.toTmdbImageUrl("w200"),
                                    contentDescription = rec.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                Box(
                                    Modifier.fillMaxSize()
                                        .background(Brush.verticalGradient(
                                            listOf(Color.Transparent,
                                                colors.cardGradientEnd.copy(alpha = 0.85f))
                                        ))
                                )
                                Text(rec.title,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.align(Alignment.BottomStart).padding(6.dp))
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun MetaChip(text: String) {
    Box(
        modifier = Modifier
            .clip(MaterialTheme.shapes.small)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
