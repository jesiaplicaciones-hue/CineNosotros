package com.mediastreamkit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.rememberNavController
import com.mediastreamkit.core.domain.repository.SettingsRepository
import com.mediastreamkit.ui.navigation.MskNavHost
import com.mediastreamkit.ui.theme.AppTheme
import com.mediastreamkit.ui.theme.MediaStreamKitTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var settingsRepository: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        // Native splash screen — holds screen while app initializes
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by settingsRepository.observeSettings()
                .collectAsStateWithLifecycle(initialValue = com.mediastreamkit.core.domain.model.AppSettings())

            val appTheme = AppTheme.fromKey(settings.themeKey)

            MediaStreamKitTheme(appTheme = appTheme) {
                MskNavHost(navController = rememberNavController())
            }
        }
    }
}
