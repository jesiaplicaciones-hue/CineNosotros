package com.mediastreamkit.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.*
import androidx.navigation.*
import androidx.navigation.compose.*
import com.mediastreamkit.core.domain.model.MediaItem
import com.mediastreamkit.feature.ai.AnalyticsScreen
import com.mediastreamkit.feature.ai.LunaScreen
import com.mediastreamkit.feature.auth.login.LoginScreen
import com.mediastreamkit.feature.auth.setup.SetupScreen
import com.mediastreamkit.feature.call.CallScreen
import com.mediastreamkit.feature.chat.ChatScreen
import com.mediastreamkit.feature.home.HomeScreen
import com.mediastreamkit.feature.home.MediaDetailScreen
import com.mediastreamkit.feature.notes.NotesScreen
import com.mediastreamkit.feature.playback.PlaybackScreen
import com.mediastreamkit.feature.settings.SettingsScreen
import com.mediastreamkit.feature.splash.SplashScreen
import com.mediastreamkit.feature.sync.SyncScreen

sealed class Screen(val route: String) {
    object Splash      : Screen("splash")
    object Setup       : Screen("setup")
    object Login       : Screen("login")
    object Home        : Screen("home/{userId}") { fun build(userId: Int) = "home/$userId" }
    object MediaDetail : Screen("media/{mediaId}") { fun build(mediaId: Int) = "media/$mediaId" }
    object Playback    : Screen("playback/{mediaId}") { fun build(mediaId: Int) = "playback/$mediaId" }
    object Sync        : Screen("sync/{mediaId}") { fun build(mediaId: Int) = "sync/$mediaId" }
    object Chat        : Screen("chat?mediaId={mediaId}") {
        fun build(mediaId: Int? = null) = if (mediaId != null) "chat?mediaId=$mediaId" else "chat"
    }
    object Luna        : Screen("luna")
    object Analytics   : Screen("analytics")
    object Settings    : Screen("settings")
    object Notes       : Screen("notes?mediaId={mediaId}") {
        fun build(mediaId: Int? = null) = if (mediaId != null) "notes?mediaId=$mediaId" else "notes"
    }
    object Call        : Screen("call")
}

@Composable
fun MskNavHost(navController: NavHostController = rememberNavController()) {
    var selectedMedia by remember { mutableStateOf<MediaItem?>(null) }

    NavHost(
        navController    = navController,
        startDestination = Screen.Splash.route,
        enterTransition  = { fadeIn(tween(280)) + slideInHorizontally { it / 5 } },
        exitTransition   = { fadeOut(tween(200)) },
        popEnterTransition  = { fadeIn(tween(280)) },
        popExitTransition   = { fadeOut(tween(200)) + slideOutHorizontally { it / 5 } }
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onNavigateToSetup = { navController.navigate(Screen.Setup.route) { popUpTo(Screen.Splash.route) { inclusive = true } } },
                onNavigateToLogin = { navController.navigate(Screen.Login.route) { popUpTo(Screen.Splash.route) { inclusive = true } } }
            )
        }
        composable(Screen.Setup.route) {
            SetupScreen(onSetupComplete = { navController.navigate(Screen.Login.route) { popUpTo(Screen.Setup.route) { inclusive = true } } })
        }
        composable(Screen.Login.route) {
            LoginScreen(onLoginSuccess = { userId ->
                navController.navigate(Screen.Home.build(userId)) { popUpTo(Screen.Login.route) { inclusive = true } }
            })
        }
        composable(Screen.Home.route, listOf(navArgument("userId") { type = NavType.IntType })) { back ->
            val userId = back.arguments?.getInt("userId") ?: 0
            HomeScreen(
                userId = userId,
                onMediaClick = { media -> selectedMedia = media; navController.navigate(Screen.MediaDetail.build(media.id)) },
                onChatClick  = { navController.navigate(Screen.Chat.build()) },
                onLunaClick  = { navController.navigate(Screen.Luna.route) },
                onSettingsClick = { navController.navigate(Screen.Settings.route) }
            )
        }
        composable(Screen.MediaDetail.route, listOf(navArgument("mediaId") { type = NavType.IntType })) { back ->
            val mediaId = back.arguments?.getInt("mediaId") ?: return@composable
            MediaDetailScreen(
                mediaId = mediaId, onBack = { navController.popBackStack() },
                onPlayClick  = { media -> selectedMedia = media; navController.navigate(Screen.Playback.build(media.id)) },
                onSyncClick  = { navController.navigate(Screen.Sync.build(it)) },
                onChatClick  = { navController.navigate(Screen.Chat.build(it)) },
                onNotesClick = { navController.navigate(Screen.Notes.build(it)) }
            )
        }
        composable(Screen.Playback.route, listOf(navArgument("mediaId") { type = NavType.IntType })) {
            val media = selectedMedia ?: return@composable
            PlaybackScreen(
                mediaItem  = media,
                onBack     = { navController.popBackStack() },
                onOpenChat = { id -> navController.navigate(Screen.Chat.build(id)) },
                onOpenSync = { id -> navController.navigate(Screen.Sync.build(id)) }
            )
        }
        composable(Screen.Sync.route, listOf(navArgument("mediaId") { type = NavType.IntType })) { back ->
            val mediaId = back.arguments?.getInt("mediaId") ?: return@composable
            SyncScreen(mediaId = mediaId, onBack = { navController.popBackStack() })
        }
        composable(Screen.Chat.route, listOf(navArgument("mediaId") { nullable = true; defaultValue = null })) { back ->
            val mediaId = back.arguments?.getString("mediaId")?.toIntOrNull()
            ChatScreen(mediaId = mediaId, onBack = { navController.popBackStack() })
        }
        composable(Screen.Luna.route)      { LunaScreen(onBack = { navController.popBackStack() }) }
        composable(Screen.Analytics.route) { AnalyticsScreen(onBack = { navController.popBackStack() }) }
        composable(Screen.Settings.route)  { SettingsScreen(onBack = { navController.popBackStack() }) }
        composable(Screen.Notes.route, listOf(navArgument("mediaId") { nullable = true; defaultValue = null })) { back ->
            val mediaId = back.arguments?.getString("mediaId")?.toIntOrNull()
            NotesScreen(mediaId = mediaId, onBack = { navController.popBackStack() })
        }
        composable(Screen.Call.route) { CallScreen(onBack = { navController.popBackStack() }) }
    }
}
