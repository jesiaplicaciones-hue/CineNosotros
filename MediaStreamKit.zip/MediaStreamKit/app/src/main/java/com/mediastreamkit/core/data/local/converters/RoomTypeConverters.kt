package com.mediastreamkit.core.data.local.converters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class RoomTypeConverters {
    private val gson = Gson()

    @TypeConverter fun fromStringList(value: List<String>): String =
        gson.toJson(value)

    @TypeConverter fun toStringList(value: String): List<String> =
        gson.fromJson(value, object : TypeToken<List<String>>() {}.type) ?: emptyList()

    @TypeConverter fun fromIntList(value: List<Int>): String =
        gson.toJson(value)

    @TypeConverter fun toIntList(value: String): List<Int> =
        gson.fromJson(value, object : TypeToken<List<Int>>() {}.type) ?: emptyList()
}
