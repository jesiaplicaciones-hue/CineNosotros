package com.mediastreamkit.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.domain.model.AppSettings
import com.mediastreamkit.core.domain.model.AutoPlayMode
import com.mediastreamkit.core.domain.repository.AnalyticsRepository
import com.mediastreamkit.core.domain.repository.SettingsRepository
import com.mediastreamkit.ui.theme.AppTheme
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val totalPlaybackMinutes: Long = 0L,
    val isLoading: Boolean = false
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val analyticsRepository: AnalyticsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsUiState())
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.observeSettings().collect { settings ->
                _state.update { it.copy(settings = settings) }
            }
        }
        viewModelScope.launch {
            val total = analyticsRepository.getTotalPlaybackTime()
            _state.update { it.copy(totalPlaybackMinutes = total) }
        }
    }

    fun setTheme(theme: AppTheme) {
        viewModelScope.launch { settingsRepository.updateTheme(theme.prefKey) }
    }

    fun setAutoPlayMode(mode: AutoPlayMode) {
        viewModelScope.launch { settingsRepository.updateAutoPlayMode(mode) }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.updateBiometricEnabled(enabled) }
    }
}
