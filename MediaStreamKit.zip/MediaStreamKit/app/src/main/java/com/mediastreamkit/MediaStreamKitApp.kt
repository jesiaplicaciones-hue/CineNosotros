package com.mediastreamkit

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class MediaStreamKitApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
        createNotificationChannels()
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)

        nm.createNotificationChannel(NotificationChannel(
            "msk_default_channel",
            "Notificaciones generales",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Notificaciones de MediaStreamKit" })

        nm.createNotificationChannel(NotificationChannel(
            "msk_sync_channel",
            "Sincronización",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Estado de sincronización de reproducción" })

        nm.createNotificationChannel(NotificationChannel(
            "msk_download_channel",
            "Descargas",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Progreso de descargas offline" })

        nm.createNotificationChannel(NotificationChannel(
            "msk_chat_channel",
            "Mensajes",
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Nuevos mensajes del chat privado" })
    }
}
