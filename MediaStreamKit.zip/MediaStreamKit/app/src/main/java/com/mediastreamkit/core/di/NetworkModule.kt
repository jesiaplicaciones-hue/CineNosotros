package com.mediastreamkit.core.di

import com.mediastreamkit.core.data.remote.websocket.MskWebSocketClient
import com.mediastreamkit.core.network.PresenceManager
import com.mediastreamkit.core.network.WebRtcManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun providePresenceManager(wsClient: MskWebSocketClient): PresenceManager =
        PresenceManager(wsClient)

    @Provides
    @Singleton
    fun provideWebRtcManager(wsClient: MskWebSocketClient): WebRtcManager =
        WebRtcManager(wsClient)
}
