package com.mediastreamkit.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.domain.model.*
import com.mediastreamkit.core.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeSectionData(
    val title: String,
    val items: List<MediaItem>,
    val category: MediaCategory? = null
)

data class HomeUiState(
    val isLoading: Boolean = true,
    val continueWatching: List<MediaItem> = emptyList(),
    val history: List<MediaItem> = emptyList(),
    val categoryA: List<MediaItem> = emptyList(),
    val categoryB: List<MediaItem> = emptyList(),
    val categoryC: List<MediaItem> = emptyList(),
    val sharedList: List<MediaItem> = emptyList(),
    val presenceStatus: PresenceStatus = PresenceStatus.OFFLINE,
    val partnerPresence: PresenceStatus = PresenceStatus.OFFLINE,
    val unreadMessages: Int = 0,
    val error: String? = null
) {
    val sections: List<HomeSectionData> get() = buildList {
        if (continueWatching.isNotEmpty())
            add(HomeSectionData("Continuar viendo", continueWatching))
        if (sharedList.isNotEmpty())
            add(HomeSectionData("Lista compartida", sharedList))
        if (categoryA.isNotEmpty())
            add(HomeSectionData("Películas", categoryA, MediaCategory.CATEGORY_A))
        if (categoryB.isNotEmpty())
            add(HomeSectionData("Series", categoryB, MediaCategory.CATEGORY_B))
        if (categoryC.isNotEmpty())
            add(HomeSectionData("Documentales", categoryC, MediaCategory.CATEGORY_C))
        if (history.isNotEmpty())
            add(HomeSectionData("Historial", history))
    }
}

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val mediaRepository: MediaRepository,
    private val sharedListRepository: SharedListRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init { observeData() }

    private fun observeData() {
        viewModelScope.launch {
            combine(
                mediaRepository.observeContinueWatching(),
                mediaRepository.observeHistory(),
                mediaRepository.observeByCategory(MediaCategory.CATEGORY_A),
                mediaRepository.observeByCategory(MediaCategory.CATEGORY_B),
                mediaRepository.observeByCategory(MediaCategory.CATEGORY_C),
                sharedListRepository.observeSharedList()
            ) { arr ->
                @Suppress("UNCHECKED_CAST")
                HomeUiState(
                    isLoading = false,
                    continueWatching = arr[0] as List<MediaItem>,
                    history         = arr[1] as List<MediaItem>,
                    categoryA       = arr[2] as List<MediaItem>,
                    categoryB       = arr[3] as List<MediaItem>,
                    categoryC       = arr[4] as List<MediaItem>,
                    sharedList      = arr[5] as List<MediaItem>
                )
            }.catch { e ->
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }.collect { state ->
                _uiState.update { current ->
                    state.copy(
                        presenceStatus = current.presenceStatus,
                        partnerPresence = current.partnerPresence,
                        unreadMessages = current.unreadMessages
                    )
                }
            }
        }
    }

    fun updatePresence(myStatus: PresenceStatus, partnerStatus: PresenceStatus) {
        _uiState.update { it.copy(presenceStatus = myStatus, partnerPresence = partnerStatus) }
    }

    fun setUnreadCount(count: Int) {
        _uiState.update { it.copy(unreadMessages = count) }
    }

    fun indexFromCsv(csv: String) {
        viewModelScope.launch {
            mediaRepository.indexFromCsv(csv)
        }
    }
}
