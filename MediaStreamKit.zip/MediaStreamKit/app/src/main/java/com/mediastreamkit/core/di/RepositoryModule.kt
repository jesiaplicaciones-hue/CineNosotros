package com.mediastreamkit.core.di

import com.mediastreamkit.core.data.repository.*
import com.mediastreamkit.core.domain.repository.*
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds @Singleton abstract fun bindUserRepo(impl: UserRepositoryImpl): UserRepository
    @Binds @Singleton abstract fun bindMediaRepo(impl: MediaRepositoryImpl): MediaRepository
    @Binds @Singleton abstract fun bindChatRepo(impl: ChatRepositoryImpl): ChatRepository
    @Binds @Singleton abstract fun bindSharedListRepo(impl: SharedListRepositoryImpl): SharedListRepository
    @Binds @Singleton abstract fun bindNoteRepo(impl: NoteRepositoryImpl): NoteRepository
    @Binds @Singleton abstract fun bindAnalyticsRepo(impl: AnalyticsRepositoryImpl): AnalyticsRepository
    @Binds @Singleton abstract fun bindSettingsRepo(impl: SettingsRepositoryImpl): SettingsRepository
}
