package com.mediastreamkit.feature.splash

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mediastreamkit.ui.components.StarParticleCanvas
import com.mediastreamkit.ui.theme.mskColors

@Composable
fun SplashScreen(
    onNavigateToSetup: () -> Unit,
    onNavigateToLogin: () -> Unit,
    viewModel: SplashViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(state.isReady) {
        if (!state.isReady) return@LaunchedEffect
        when (state.navigateTo) {
            SplashDestination.SETUP -> onNavigateToSetup()
            SplashDestination.LOGIN -> onNavigateToLogin()
            SplashDestination.NONE  -> Unit
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        // Star particle background
        StarParticleCanvas(modifier = Modifier.fillMaxSize())

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 40.dp)
        ) {
            // App logo / title
            Text(
                text = "MediaStreamKit",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Sincronización P2P Privada",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Animated phrase with fade-in/fade-out
            var phraseVisible by remember { mutableStateOf(false) }
            LaunchedEffect(state.phrase) {
                if (state.phrase.isNotBlank()) phraseVisible = true
            }

            AnimatedVisibility(
                visible = phraseVisible && state.phrase.isNotBlank(),
                enter = fadeIn(tween(800)),
                exit = fadeOut(tween(600))
            ) {
                Text(
                    text = "\"${state.phrase}\"",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(64.dp))

            // Loading indicator
            if (!state.isReady) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp),
                    strokeWidth = 2.dp
                )
            }
        }
    }
}
