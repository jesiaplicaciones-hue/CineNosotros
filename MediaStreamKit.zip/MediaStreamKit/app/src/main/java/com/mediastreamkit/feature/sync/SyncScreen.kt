package com.mediastreamkit.feature.sync

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mediastreamkit.ui.components.StarParticleCanvas

@Composable
fun SyncScreen(
    mediaId: Int,
    onBack: () -> Unit,
    viewModel: SyncViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var joinCodeInput by remember { mutableStateOf("") }
    var showJoinDialog by remember { mutableStateOf(false) }

    // Network lost dialog
    if (state.networkLost) {
        AlertDialog(
            onDismissRequest = {},
            icon = { Icon(Icons.Default.WifiOff, null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Conexión perdida") },
            text = { Text("La reproducción ha sido pausada. Esperando reconexión…") },
            confirmButton = {
                TextButton(onClick = viewModel::dismissNetworkLostDialog) { Text("Entendido") }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (showJoinDialog) {
        AlertDialog(
            onDismissRequest = { showJoinDialog = false },
            title = { Text("Unirse a sala") },
            text = {
                OutlinedTextField(
                    value = joinCodeInput,
                    onValueChange = { joinCodeInput = it.uppercase().take(6) },
                    label = { Text("Código de sala (6 caracteres)") },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.joinRoom(joinCodeInput)
                    showJoinDialog = false
                }, enabled = joinCodeInput.length == 6) { Text("Unirse") }
            },
            dismissButton = {
                TextButton(onClick = { showJoinDialog = false }) { Text("Cancelar") }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        StarParticleCanvas(Modifier.fillMaxSize(), particleCount = 30)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.Start)) {
                Icon(Icons.Default.ArrowBack, "Volver",
                    tint = MaterialTheme.colorScheme.onBackground)
            }

            Spacer(Modifier.height(16.dp))

            AnimatedContent(targetState = state.isRoomReady, label = "sync_content") { ready ->
                if (ready) {
                    ActiveRoomPanel(state = state, viewModel = viewModel)
                } else {
                    RoomSetupPanel(
                        state = state,
                        onCreateRoom = { viewModel.createRoom(mediaId) },
                        onJoinRoom   = { showJoinDialog = true }
                    )
                }
            }
        }
    }
}

@Composable
private fun RoomSetupPanel(
    state: SyncUiState,
    onCreateRoom: () -> Unit,
    onJoinRoom: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Icon(Icons.Default.Sync, null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary)

            Text("Sala de Sincronización",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center)

            Text("Crea una sala y comparte el código con tu compañero, o únete a una sala existente.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center)

            if (state.roomCode.isNotBlank()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Código de sala", style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(state.roomCode,
                            style = MaterialTheme.typography.displaySmall,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 8.dp.value.let {
                                androidx.compose.ui.unit.TextUnit(it, androidx.compose.ui.unit.TextUnitType.Sp)
                            })
                        Text("Esperando al compañero…",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                    }
                }
            }

            Button(
                onClick = onCreateRoom,
                enabled = !state.isCreatingRoom,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (state.isCreatingRoom) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Icon(Icons.Default.AddCircle, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Crear sala")
                }
            }

            OutlinedButton(
                onClick = onJoinRoom,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.Login, null)
                Spacer(Modifier.width(8.dp))
                Text("Unirse con código")
            }
        }
    }
}

@Composable
private fun ActiveRoomPanel(
    state: SyncUiState,
    viewModel: SyncViewModel
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = MaterialTheme.shapes.medium
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    Modifier.size(10.dp)
                        .background(com.mediastreamkit.ui.theme.OnlineGreen,
                            MaterialTheme.shapes.extraSmall)
                )
                Text("Sala ${state.roomCode} — Sincronizados",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }

        Text("RTT: ${state.rttMs}ms",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        // Playback controls
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            FilledTonalIconButton(
                onClick = { viewModel.onLocalSeek(
                    (state.currentPositionSec - 10f).coerceAtLeast(0f)) },
                modifier = Modifier.size(56.dp)
            ) {
                Icon(Icons.Default.Replay10, "Retroceder 10s")
            }

            if (state.playbackState == com.mediastreamkit.core.domain.model.PlaybackState.PLAY) {
                FilledIconButton(
                    onClick = { viewModel.onLocalPause(state.currentPositionSec) },
                    modifier = Modifier.size(64.dp)
                ) {
                    Icon(Icons.Default.Pause, "Pausar", Modifier.size(32.dp))
                }
            } else {
                FilledIconButton(
                    onClick = { viewModel.onLocalPlay(state.currentPositionSec) },
                    modifier = Modifier.size(64.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, "Reproducir", Modifier.size(32.dp))
                }
            }

            FilledTonalIconButton(
                onClick = { viewModel.onLocalSeek(state.currentPositionSec + 10f) },
                modifier = Modifier.size(56.dp)
            ) {
                Icon(Icons.Default.Forward10, "Avanzar 10s")
            }
        }

        Text(
            text = "Posición: ${state.currentPositionSec.toInt() / 60}m ${state.currentPositionSec.toInt() % 60}s",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
