package com.mediastreamkit.core.network

import com.mediastreamkit.core.data.remote.websocket.MskWebSocketClient
import com.mediastreamkit.core.data.remote.websocket.WsEvent
import com.mediastreamkit.core.domain.model.PresenceStatus
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PresenceManager @Inject constructor(
    private val wsClient: MskWebSocketClient
) {
    private val _myStatus      = MutableStateFlow(PresenceStatus.OFFLINE)
    private val _partnerStatus = MutableStateFlow(PresenceStatus.OFFLINE)

    val myStatus: StateFlow<PresenceStatus>      = _myStatus.asStateFlow()
    val partnerStatus: StateFlow<PresenceStatus> = _partnerStatus.asStateFlow()

    private var scope: CoroutineScope? = null

    fun start(userId: Int, coroutineScope: CoroutineScope) {
        scope = coroutineScope
        _myStatus.value = PresenceStatus.ONLINE

        // Observe incoming presence events from WS
        coroutineScope.launch {
            wsClient.events
                .filterIsInstance<WsEvent.PresenceUpdate>()
                .collect { event ->
                    if (event.userId != userId) {
                        _partnerStatus.value = when (event.status) {
                            "online"  -> PresenceStatus.ONLINE
                            "away"    -> PresenceStatus.AWAY
                            else      -> PresenceStatus.OFFLINE
                        }
                        Timber.d("Partner presence: ${event.status}")
                    }
                }
        }

        // Observe disconnection
        coroutineScope.launch {
            wsClient.events
                .filterIsInstance<WsEvent.Disconnected>()
                .collect {
                    _myStatus.value = PresenceStatus.OFFLINE
                }
        }

        coroutineScope.launch {
            wsClient.events
                .filterIsInstance<WsEvent.Connected>()
                .collect {
                    _myStatus.value = PresenceStatus.ONLINE
                }
        }
    }

    fun stop() {
        _myStatus.value = PresenceStatus.OFFLINE
        scope = null
    }
}
