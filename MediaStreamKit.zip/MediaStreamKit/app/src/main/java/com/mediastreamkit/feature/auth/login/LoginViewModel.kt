package com.mediastreamkit.feature.auth.login

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.domain.model.UserProfile
import com.mediastreamkit.core.domain.repository.SettingsRepository
import com.mediastreamkit.core.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class LoginUiState {
    object Idle : LoginUiState()
    object Loading : LoginUiState()
    data class ProfilesLoaded(val profiles: List<UserProfile>) : LoginUiState()
    data class AwaitingPassword(val profile: UserProfile) : LoginUiState()
    data class Success(val userId: Int) : LoginUiState()
    data class Error(val message: String) : LoginUiState()
}

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow<LoginUiState>(LoginUiState.Loading)
    val state: StateFlow<LoginUiState> = _state.asStateFlow()

    private val _passwordInput = MutableStateFlow("")
    val passwordInput: StateFlow<String> = _passwordInput.asStateFlow()

    init { loadProfiles() }

    private fun loadProfiles() {
        viewModelScope.launch {
            userRepository.observeProfiles()
                .catch { _state.emit(LoginUiState.Error(it.message ?: "Error")) }
                .collect { profiles ->
                    _state.value = LoginUiState.ProfilesLoaded(profiles)
                }
        }
    }

    fun selectProfile(profile: UserProfile) {
        _passwordInput.value = ""
        _state.value = LoginUiState.AwaitingPassword(profile)
    }

    fun onPasswordChange(pw: String) { _passwordInput.value = pw }

    fun submitPassword() {
        val current = _state.value as? LoginUiState.AwaitingPassword ?: return
        viewModelScope.launch {
            _state.value = LoginUiState.Loading
            val ok = userRepository.verifyPassword(current.profile.id, _passwordInput.value)
            if (ok) {
                settingsRepository.setActiveUserId(current.profile.id)
                _state.value = LoginUiState.Success(current.profile.id)
            } else {
                _state.value = LoginUiState.Error("Contraseña incorrecta")
            }
        }
    }

    fun launchBiometric(activity: FragmentActivity, profile: UserProfile) {
        val biometricManager = BiometricManager.from(activity)
        if (biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
            ) != BiometricManager.BIOMETRIC_SUCCESS
        ) {
            selectProfile(profile)
            return
        }

        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    viewModelScope.launch {
                        settingsRepository.setActiveUserId(profile.id)
                        _state.value = LoginUiState.Success(profile.id)
                    }
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    // Fall back to password
                    selectProfile(profile)
                }
                override fun onAuthenticationFailed() {
                    _state.value = LoginUiState.Error("Biometría fallida — usa contraseña")
                }
            }
        )

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Autenticación biométrica")
            .setSubtitle("Inicia sesión como ${profile.username}")
            .setNegativeButtonText("Usar contraseña")
            .build()

        prompt.authenticate(info)
    }

    fun cancelPasswordEntry() {
        _state.value = LoginUiState.Loading
        loadProfiles()
    }
}
