package com.mediastreamkit.core.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.mediastreamkit.BuildConfig
import com.mediastreamkit.core.data.local.MskDatabase
import com.mediastreamkit.core.data.local.dao.*
import com.mediastreamkit.core.data.remote.api.TmdbApi
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.ktor.client.*
import io.ktor.client.engine.android.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.logging.*
import io.ktor.client.plugins.websocket.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences>
        by preferencesDataStore(name = "msk_settings")

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    // ── DataStore ─────────────────────────────────────────────────────────────

    @Provides @Singleton
    fun provideDataStore(@ApplicationContext ctx: Context): DataStore<Preferences> =
        ctx.dataStore

    // ── Database ──────────────────────────────────────────────────────────────

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): MskDatabase =
        MskDatabase.buildEncrypted(ctx, BuildConfig.DB_PASSPHRASE_KEY)

    @Provides fun provideUserProfileDao(db: MskDatabase): UserProfileDao = db.userProfileDao()
    @Provides fun provideMediaItemDao(db: MskDatabase): MediaItemDao = db.mediaItemDao()
    @Provides fun provideChatMessageDao(db: MskDatabase): ChatMessageDao = db.chatMessageDao()
    @Provides fun providePlaybackEventDao(db: MskDatabase): PlaybackEventDao = db.playbackEventDao()
    @Provides fun provideSharedListDao(db: MskDatabase): SharedListDao = db.sharedListDao()
    @Provides fun provideNoteDao(db: MskDatabase): NoteDao = db.noteDao()
    @Provides fun provideGenrePreferenceDao(db: MskDatabase): GenrePreferenceDao = db.genrePreferenceDao()
    @Provides fun provideDownloadQueueDao(db: MskDatabase): DownloadQueueDao = db.downloadQueueDao()

    // ── OkHttp + Retrofit ─────────────────────────────────────────────────────

    @Provides @Singleton
    fun provideOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY
                    else HttpLoggingInterceptor.Level.NONE
        })
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .addHeader("Authorization", "Bearer ${BuildConfig.TMDB_API_KEY}")
                .addHeader("Accept", "application/json")
                .build()
            chain.proceed(request)
        }
        .build()

    @Provides @Singleton
    fun provideTmdbRetrofit(okHttpClient: OkHttpClient): Retrofit = Retrofit.Builder()
        .baseUrl(BuildConfig.TMDB_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    @Provides @Singleton
    fun provideTmdbApi(retrofit: Retrofit): TmdbApi = retrofit.create(TmdbApi::class.java)

    // ── Ktor WebSocket Client ─────────────────────────────────────────────────

    @Provides @Singleton
    fun provideKtorJson(): Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }

    @Provides @Singleton
    fun provideKtorClient(json: Json): HttpClient = HttpClient(Android) {
        install(WebSockets) {
            pingInterval = 20_000
        }
        install(ContentNegotiation) {
            json(json)
        }
        install(Logging) {
            level = if (BuildConfig.DEBUG) LogLevel.BODY else LogLevel.NONE
        }
        engine {
            connectTimeout = 30_000
            socketTimeout  = 30_000
        }
    }
}
