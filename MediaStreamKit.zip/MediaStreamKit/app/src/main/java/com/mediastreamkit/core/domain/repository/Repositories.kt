package com.mediastreamkit.core.domain.repository

import com.mediastreamkit.core.domain.model.*
import com.mediastreamkit.core.utils.Result
import kotlinx.coroutines.flow.Flow

interface UserRepository {
    fun observeProfiles(): Flow<List<UserProfile>>
    suspend fun getProfile(id: Int): UserProfile?
    suspend fun saveProfile(profile: UserProfile)
    suspend fun profilesExist(): Boolean
    suspend fun verifyPassword(userId: Int, password: String): Boolean
}

interface MediaRepository {
    fun observeAll(): Flow<List<MediaItem>>
    fun observeByCategory(category: MediaCategory): Flow<List<MediaItem>>
    fun observeContinueWatching(): Flow<List<MediaItem>>
    fun observeHistory(): Flow<List<MediaItem>>
    fun observeDownloaded(): Flow<List<MediaItem>>
    suspend fun getById(id: Int): MediaItem?
    suspend fun indexFromCsv(csv: String): Result<Int>
    suspend fun markWatched(id: Int, progress: Float)
    suspend fun getRecommendations(mediaId: Int): Result<List<MediaItem>>
}

interface ChatRepository {
    fun observeGeneralChat(): Flow<List<ChatMessage>>
    fun observeContextualChat(mediaId: Int): Flow<List<ChatMessage>>
    fun observeUnreadCount(myUserId: Int): Flow<Int>
    suspend fun sendMessage(message: ChatMessage)
    suspend fun markAllRead(myUserId: Int)
}

interface SharedListRepository {
    fun observeSharedList(): Flow<List<MediaItem>>
    suspend fun addToSharedList(mediaId: Int, addedByUserId: Int)
    suspend fun removeFromSharedList(mediaId: Int)
    suspend fun getUncompletedSagas(): List<MediaItem>
    suspend fun filterByGenre(genreId: Int): List<MediaItem>
    suspend fun exists(mediaId: Int): Boolean
}

interface NoteRepository {
    fun observeNotes(userId: Int): Flow<List<Note>>
    fun observeNotesForMedia(userId: Int, mediaId: Int): Flow<List<Note>>
    suspend fun saveNote(note: Note)
    suspend fun deleteNote(noteId: String)
}

interface AnalyticsRepository {
    suspend fun recordPlaybackEvent(event: PlaybackEvent)
    suspend fun getWatchedGenreVectors(userId: Int): List<GenrePreference>
    suspend fun getTopWatchedMedia(userId: Int): List<Pair<Int, Long>>
    suspend fun getTotalPlaybackTime(): Long
}

interface SettingsRepository {
    fun observeSettings(): Flow<AppSettings>
    suspend fun updateTheme(themeKey: String)
    suspend fun updateAutoPlayMode(mode: AutoPlayMode)
    suspend fun updateBiometricEnabled(enabled: Boolean)
    suspend fun isFirstRun(): Boolean
    suspend fun setFirstRunComplete()
    suspend fun getActiveUserId(): Int
    suspend fun setActiveUserId(id: Int)
}
