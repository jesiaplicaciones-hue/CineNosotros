package com.mediastreamkit.core.data.remote.api

import com.mediastreamkit.core.data.remote.dto.*
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface TmdbApi {

    @GET("search/movie")
    suspend fun searchMovie(
        @Query("query") query: String,
        @Query("language") language: String = "es-ES"
    ): TmdbSearchResponse

    @GET("movie/{movie_id}")
    suspend fun getMovieDetail(
        @Path("movie_id") movieId: Int,
        @Query("language") language: String = "es-ES",
        @Query("append_to_response") appendToResponse: String = "belongs_to_collection,genres"
    ): TmdbMovieDetailDto

    @GET("movie/{movie_id}/recommendations")
    suspend fun getRecommendations(
        @Path("movie_id") movieId: Int,
        @Query("language") language: String = "es-ES",
        @Query("page") page: Int = 1
    ): TmdbSearchResponse

    @GET("genre/movie/list")
    suspend fun getGenres(
        @Query("language") language: String = "es-ES"
    ): TmdbGenreListResponse

    @GET("collection/{collection_id}")
    suspend fun getCollection(
        @Path("collection_id") collectionId: Int,
        @Query("language") language: String = "es-ES"
    ): TmdbCollectionDto

    @GET("discover/movie")
    suspend fun discoverByGenre(
        @Query("with_genres") genreId: Int,
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("language") language: String = "es-ES",
        @Query("page") page: Int = 1
    ): TmdbSearchResponse
}
