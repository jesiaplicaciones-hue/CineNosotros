package com.mediastreamkit.core.domain.model

import kotlinx.serialization.Serializable

// ─── User / Auth ──────────────────────────────────────────────────────────────

data class UserProfile(
    val id: Int,           // 0 or 1 (only two users)
    val username: String,
    val avatarId: Int,
    val profilePicture: ByteArray? = null,
    val passwordHash: String      // bcrypt / SHA-256
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is UserProfile) return false
        return id == other.id && username == other.username
    }
    override fun hashCode(): Int = 31 * id + username.hashCode()
}

data class SessionState(
    val userId: Int,
    val isAuthenticated: Boolean = false,
    val sessionKey: String = ""
)

// ─── Presence ─────────────────────────────────────────────────────────────────

enum class PresenceStatus { ONLINE, OFFLINE, AWAY }

data class UserPresence(
    val userId: Int,
    val status: PresenceStatus,
    val lastSeen: Long = System.currentTimeMillis()
)

// ─── Media / Catalog ──────────────────────────────────────────────────────────

enum class MediaCategory { CATEGORY_A, CATEGORY_B, CATEGORY_C }

data class MediaItem(
    val id: Int,
    val tmdbId: Int,
    val title: String,
    val posterPath: String?,
    val backdropPath: String?,
    val runtimeMinutes: Int,
    val genres: List<String>,
    val releaseDate: String,
    val overview: String,
    val sagaId: Int?,
    val sagaName: String?,
    val category: MediaCategory,
    val isWatched: Boolean = false,
    val watchedProgress: Float = 0f,   // 0..1
    val isDownloaded: Boolean = false
)

data class MediaSaga(
    val id: Int,
    val name: String,
    val items: List<MediaItem>
)

// ─── Playback Sync ────────────────────────────────────────────────────────────

enum class PlaybackState { PLAY, PAUSE, SEEK, BUFFERING, ENDED }

@Serializable
data class PlaybackPayload(
    val playbackState: String,
    val timestampSeconds: Float,
    val clientEpochTime: Long,
    val roomCode: String,
    val mediaId: Int
)

data class SyncRoom(
    val code: String,
    val mediaId: Int,
    val clientAConnected: Boolean = false,
    val clientBConnected: Boolean = false
)

// ─── Chat ─────────────────────────────────────────────────────────────────────

enum class MessageType { TEXT, IMAGE, AUDIO, REACTION, SYSTEM }

data class ChatMessage(
    val messageId: String,
    val mediaId: Int?,       // nullable for general chat
    val senderId: Int,
    val payloadText: String,
    val messageType: MessageType,
    val blobUri: String?,    // AES-encrypted local URI for media
    val timestamp: Long,
    val isEncrypted: Boolean = true,
    val reactionEmoji: String? = null,
    val isDelivered: Boolean = false,
    val isRead: Boolean = false
)

// ─── AI / Luna ────────────────────────────────────────────────────────────────

data class LunaMessage(
    val id: String,
    val role: String,  // "user" | "assistant"
    val content: String,
    val timestamp: Long,
    val toolCalls: List<LunaToolCall>? = null
)

data class LunaToolCall(
    val name: String,
    val arguments: Map<String, Any>
)

enum class LunaToolName(val fnName: String) {
    ADD_TO_SHARED_LIST("add_to_shared_list"),
    FILTER_CATALOG_BY_GENRE("filter_catalog_by_genre"),
    GET_UNCOMPLETED_SAGAS("get_uncompleted_sagas"),
    GET_USER_HISTORY("get_user_history"),
    ANALYZE_CROSS_PREFERENCES("analyze_cross_preferences")
}

// ─── Analytics ────────────────────────────────────────────────────────────────

data class PlaybackEvent(
    val mediaId: Int,
    val userId: Int,
    val eventType: PlaybackState,
    val positionSeconds: Float,
    val timestamp: Long
)

data class GenrePreference(
    val genreId: Int,
    val genreName: String,
    val userId: Int,
    val watchCount: Int,
    val totalMinutes: Long
)

data class AfinityReport(
    val sharedGenres: List<String>,
    val recommendedMediaIds: List<Int>,
    val confidenceScore: Float,
    val reasoning: String
)

// ─── Notes ────────────────────────────────────────────────────────────────────

data class Note(
    val noteId: String,
    val userId: Int,
    val mediaId: Int?,
    val content: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isPinned: Boolean = false
)

// ─── Settings ─────────────────────────────────────────────────────────────────

enum class AutoPlayMode(val key: String) {
    ASK("ask"),
    AUTO("auto"),
    MANUAL("manual")
}

data class AppSettings(
    val themeKey: String = "cosmic_purple",
    val autoPlayMode: AutoPlayMode = AutoPlayMode.ASK,
    val biometricEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val offlineModeEnabled: Boolean = false
)
