package com.mediastreamkit.feature.auth.setup

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediastreamkit.core.domain.model.UserProfile
import com.mediastreamkit.core.domain.repository.SettingsRepository
import com.mediastreamkit.core.domain.repository.UserRepository
import com.mediastreamkit.core.security.PasswordHasher
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import javax.inject.Inject

data class SetupUiState(
    val currentStep: Int = 0,          // 0=User1, 1=User2, 2=Done
    val user1: UserFormState = UserFormState(id = 0),
    val user2: UserFormState = UserFormState(id = 1),
    val isLoading: Boolean = false,
    val error: String? = null,
    val isComplete: Boolean = false
)

data class UserFormState(
    val id: Int,
    val username: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val avatarId: Int = 0,
    val pictureBitmap: ByteArray? = null,
    val usernameError: String? = null,
    val passwordError: String? = null
) {
    fun isValid(): Boolean =
        username.length >= 3 &&
        password.length >= 6 &&
        password == confirmPassword

    override fun equals(other: Any?) = other is UserFormState && id == other.id
    override fun hashCode() = id
}

@HiltViewModel
class SetupViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val settingsRepository: SettingsRepository,
    private val passwordHasher: PasswordHasher
) : ViewModel() {

    private val _state = MutableStateFlow(SetupUiState())
    val state: StateFlow<SetupUiState> = _state.asStateFlow()

    val AVATAR_COUNT = 8

    fun updateUser1(block: UserFormState.() -> UserFormState) {
        _state.update { it.copy(user1 = it.user1.block()) }
    }

    fun updateUser2(block: UserFormState.() -> UserFormState) {
        _state.update { it.copy(user2 = it.user2.block()) }
    }

    fun nextStep() {
        val s = _state.value
        when (s.currentStep) {
            0 -> {
                if (!s.user1.isValid()) {
                    _state.update { it.copy(user1 = it.user1.copy(
                        usernameError = if (s.user1.username.length < 3) "Mínimo 3 caracteres" else null,
                        passwordError = if (s.user1.password != s.user1.confirmPassword) "Las contraseñas no coinciden" else null
                    )) }
                    return
                }
                _state.update { it.copy(currentStep = 1) }
            }
            1 -> {
                if (!s.user2.isValid()) {
                    _state.update { it.copy(user2 = it.user2.copy(
                        usernameError = if (s.user2.username.length < 3) "Mínimo 3 caracteres" else null,
                        passwordError = if (s.user2.password != s.user2.confirmPassword) "Las contraseñas no coinciden" else null
                    )) }
                    return
                }
                saveProfiles()
            }
        }
    }

    private fun saveProfiles() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val s = _state.value
                listOf(s.user1, s.user2).forEach { form ->
                    val profile = UserProfile(
                        id = form.id,
                        username = form.username,
                        avatarId = form.avatarId,
                        profilePicture = form.pictureBitmap,
                        passwordHash = passwordHasher.encode(form.password)
                    )
                    userRepository.saveProfile(profile)
                }
                settingsRepository.setFirstRunComplete()
                _state.update { it.copy(isLoading = false, isComplete = true, currentStep = 2) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }
}
