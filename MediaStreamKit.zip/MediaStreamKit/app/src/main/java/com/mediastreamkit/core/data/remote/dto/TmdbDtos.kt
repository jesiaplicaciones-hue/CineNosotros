package com.mediastreamkit.core.data.remote.dto

import com.google.gson.annotations.SerializedName

data class TmdbSearchResponse(
    val page: Int,
    val results: List<TmdbMovieSummaryDto>,
    @SerializedName("total_results") val totalResults: Int,
    @SerializedName("total_pages") val totalPages: Int
)

data class TmdbMovieSummaryDto(
    val id: Int,
    val title: String,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("release_date") val releaseDate: String?,
    val overview: String?,
    @SerializedName("genre_ids") val genreIds: List<Int>
)

data class TmdbMovieDetailDto(
    val id: Int,
    val title: String,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    val runtime: Int?,
    val genres: List<TmdbGenreDto>,
    @SerializedName("release_date") val releaseDate: String?,
    val overview: String?,
    @SerializedName("belongs_to_collection") val collection: TmdbCollectionRefDto?
)

data class TmdbGenreDto(val id: Int, val name: String)

data class TmdbCollectionRefDto(val id: Int, val name: String)

data class TmdbCollectionDto(
    val id: Int,
    val name: String,
    val parts: List<TmdbMovieSummaryDto>
)

data class TmdbGenreListResponse(val genres: List<TmdbGenreDto>)
