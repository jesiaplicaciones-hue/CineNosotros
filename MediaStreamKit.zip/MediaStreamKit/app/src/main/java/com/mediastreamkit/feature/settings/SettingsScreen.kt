package com.mediastreamkit.feature.settings

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mediastreamkit.core.domain.model.AutoPlayMode
import com.mediastreamkit.core.utils.toReadableDuration
import com.mediastreamkit.ui.theme.AppTheme
import com.mediastreamkit.ui.theme.CosmicPurplePrimary
import com.mediastreamkit.ui.theme.GalaxyBluePrimary
import com.mediastreamkit.ui.theme.RomanticPinkPrimary
import com.mediastreamkit.ui.theme.ElegantBlackPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Volver",
                            tint = MaterialTheme.colorScheme.onSurface)
                    }
                },
                title = { Text("Ajustes", style = MaterialTheme.typography.titleLarge) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ── Estadísticas ──────────────────────────────────────────────────
            SettingsSection(title = "Estadísticas") {
                StatRow(
                    icon = Icons.Default.Timer,
                    label = "Tiempo total reproducido",
                    value = (state.totalPlaybackMinutes * 60).toReadableDuration()
                )
            }

            // ── Tema visual ───────────────────────────────────────────────────
            SettingsSection(title = "Tema visual") {
                val currentTheme = AppTheme.fromKey(state.settings.themeKey)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppTheme.entries.forEach { theme ->
                        ThemeOption(
                            theme = theme,
                            isSelected = theme == currentTheme,
                            onSelect = { viewModel.setTheme(theme) }
                        )
                    }
                }
            }

            // ── Reproducción automática ────────────────────────────────────────
            SettingsSection(title = "Reproducción automática") {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    AutoPlayMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.small)
                                .clickable { viewModel.setAutoPlayMode(mode) }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            RadioButton(
                                selected = state.settings.autoPlayMode == mode,
                                onClick = { viewModel.setAutoPlayMode(mode) },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Column {
                                Text(when (mode) {
                                    AutoPlayMode.ASK    -> "Preguntar siempre"
                                    AutoPlayMode.AUTO   -> "Reproducción automática"
                                    AutoPlayMode.MANUAL -> "Control manual"
                                }, style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface)
                                Text(when (mode) {
                                    AutoPlayMode.ASK    -> "Muestra opciones al terminar"
                                    AutoPlayMode.AUTO   -> "Reproduce el siguiente automáticamente"
                                    AutoPlayMode.MANUAL -> "No avanza al siguiente"
                                }, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            // ── Seguridad ─────────────────────────────────────────────────────
            SettingsSection(title = "Seguridad") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Default.Fingerprint, null,
                            tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text("Autenticación biométrica",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface)
                            Text("Huella dactilar o reconocimiento facial",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Switch(
                        checked = state.settings.biometricEnabled,
                        onCheckedChange = viewModel::setBiometricEnabled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary)
                    )
                }
            }

            // ── Acerca de ─────────────────────────────────────────────────────
            SettingsSection(title = "Acerca de") {
                Text("MediaStreamKit v1.0.0",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface)
                Text("Plataforma P2P privada de sincronización multimedia",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text("Base de datos cifrada con SQLCipher • AES-256 • WebRTC",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary)
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            content()
        }
    }
}

@Composable
private fun StatRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface)
        }
        Text(value, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun ThemeOption(theme: AppTheme, isSelected: Boolean, onSelect: () -> Unit) {
    val themeColor = when (theme) {
        AppTheme.COSMIC_PURPLE -> CosmicPurplePrimary
        AppTheme.GALAXY_BLUE   -> GalaxyBluePrimary
        AppTheme.ROMANTIC_PINK -> RomanticPinkPrimary
        AppTheme.ELEGANT_BLACK -> ElegantBlackPrimary
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) themeColor else androidx.compose.ui.graphics.Color.Transparent,
                shape = MaterialTheme.shapes.medium
            )
            .clickable(onClick = onSelect)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier
                .size(32.dp)
                .clip(MaterialTheme.shapes.small)
                .background(themeColor)
        )
        Text(theme.displayName, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface)
        if (isSelected) {
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.Check, null,
                tint = themeColor, modifier = Modifier.size(18.dp))
        }
    }
}
