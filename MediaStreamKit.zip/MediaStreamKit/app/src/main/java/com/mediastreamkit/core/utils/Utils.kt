package com.mediastreamkit.core.utils

sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val exception: Throwable, val message: String = exception.message ?: "Unknown error") : Result<Nothing>()
    object Loading : Result<Nothing>()

    val isSuccess get() = this is Success
    val isError   get() = this is Error
    val isLoading get() = this is Loading

    fun getOrNull(): T? = if (this is Success) data else null
    fun errorOrNull(): Throwable? = if (this is Error) exception else null
}

inline fun <T> safeCall(block: () -> T): Result<T> = try {
    Result.Success(block())
} catch (e: Exception) {
    Result.Error(e)
}

suspend inline fun <T> safeSuspendCall(crossinline block: suspend () -> T): Result<T> = try {
    Result.Success(block())
} catch (e: Exception) {
    Result.Error(e)
}

fun String.toTmdbImageUrl(size: String = "w500"): String =
    if (isBlank()) "" else "https://image.tmdb.org/t/p/$size$this"

fun Long.toReadableDuration(): String {
    val hours = this / 3600
    val minutes = (this % 3600) / 60
    return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
}

/** Fisher-Yates shuffle extension */
fun <T> MutableList<T>.shuffle(): MutableList<T> {
    val rng = java.util.Random()
    for (i in size - 1 downTo 1) {
        val j = rng.nextInt(i + 1)
        val tmp = this[i]; this[i] = this[j]; this[j] = tmp
    }
    return this
}

/** Generate a random alphanumeric room code of [length] characters */
fun generateRoomCode(length: Int = 6): String {
    val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return (1..length).map { chars.random() }.joinToString("")
}
