package com.mediastreamkit.core.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.mediastreamkit.core.data.local.converters.RoomTypeConverters
import com.mediastreamkit.core.data.local.dao.*
import com.mediastreamkit.core.data.local.entities.*
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

@Database(
    entities = [
        UserProfileEntity::class,
        MediaItemEntity::class,
        ChatMessageEntity::class,
        ContextualMessageEntity::class,
        PlaybackEventEntity::class,
        SharedListEntity::class,
        NoteEntity::class,
        GenrePreferenceEntity::class,
        DownloadQueueEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(RoomTypeConverters::class)
abstract class MskDatabase : RoomDatabase() {

    abstract fun userProfileDao(): UserProfileDao
    abstract fun mediaItemDao(): MediaItemDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun playbackEventDao(): PlaybackEventDao
    abstract fun sharedListDao(): SharedListDao
    abstract fun noteDao(): NoteDao
    abstract fun genrePreferenceDao(): GenrePreferenceDao
    abstract fun downloadQueueDao(): DownloadQueueDao

    companion object {
        private const val DB_NAME = "msk_database.db"

        fun buildEncrypted(context: Context, passphrase: String): MskDatabase {
            val passphraseBytes = SQLiteDatabase.getBytes(passphrase.toCharArray())
            val factory = SupportFactory(passphraseBytes)
            return Room.databaseBuilder(context, MskDatabase::class.java, DB_NAME)
                .openHelperFactory(factory)
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}
