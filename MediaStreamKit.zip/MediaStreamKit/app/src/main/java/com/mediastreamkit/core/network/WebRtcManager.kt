package com.mediastreamkit.core.network

import android.content.Context
import com.mediastreamkit.core.data.remote.websocket.MskWebSocketClient
import io.getstream.webrtc.android.ktx.audioTrack
import io.getstream.webrtc.android.ktx.videoTrack
import kotlinx.coroutines.flow.*
import org.webrtc.*
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

data class WebRtcState(
    val isCallActive: Boolean = false,
    val isAudioEnabled: Boolean = true,
    val isVideoEnabled: Boolean = false,
    val localSdp: String = "",
    val error: String? = null
)

@Singleton
class WebRtcManager @Inject constructor(
    private val wsClient: MskWebSocketClient
) {
    private val _state = MutableStateFlow(WebRtcState())
    val state: StateFlow<WebRtcState> = _state.asStateFlow()

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var localAudioTrack: AudioTrack? = null
    private var localVideoTrack: VideoTrack? = null

    // Remote video renderer set from UI
    var remoteVideoSink: VideoSink? = null
    var localVideoSink: VideoSink? = null

    private val stunServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
        // Replace with your TURN server credentials in production:
        PeerConnection.IceServer.builder("turn:your-turn-server.com:3478")
            .setUsername("your_user")
            .setPassword("your_password")
            .createIceServer()
    )

    fun initialize(context: Context) {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        val options = PeerConnectionFactory.Options()
        val encoderFactory = DefaultVideoEncoderFactory(
            EglBase.create().eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(
            EglBase.create().eglBaseContext)

        peerConnectionFactory = PeerConnectionFactory.builder()
            .setOptions(options)
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        Timber.d("WebRTC PeerConnectionFactory initialized")
    }

    fun startCall(context: Context, withVideo: Boolean = false) {
        val factory = peerConnectionFactory ?: run {
            initialize(context)
            peerConnectionFactory!!
        }

        val rtcConfig = PeerConnection.RTCConfiguration(stunServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }

        peerConnection = factory.createPeerConnection(
            rtcConfig,
            object : PeerConnection.Observer {
                override fun onIceCandidate(candidate: IceCandidate) {
                    // Send ICE candidate to remote peer via WebSocket
                    wsClient.sendRaw(kotlinx.serialization.json.buildJsonObject {
                        put("type", kotlinx.serialization.json.JsonPrimitive("ice_candidate"))
                        put("candidate", kotlinx.serialization.json.JsonPrimitive(candidate.sdp))
                        put("sdpMid", kotlinx.serialization.json.JsonPrimitive(candidate.sdpMid))
                        put("sdpMLineIndex", kotlinx.serialization.json.JsonPrimitive(candidate.sdpMLineIndex))
                    }.toString())
                }
                override fun onTrack(transceiver: RtpTransceiver) {
                    transceiver.receiver.track()?.let { track ->
                        if (track is VideoTrack) {
                            remoteVideoSink?.let { track.addSink(it) }
                        }
                    }
                }
                override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
                    Timber.d("WebRTC connection state: $newState")
                    _state.update { it.copy(isCallActive =
                        newState == PeerConnection.PeerConnectionState.CONNECTED) }
                }
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {}
                override fun onSignalingChange(state: PeerConnection.SignalingState) {}
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
                override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
                override fun onAddStream(p0: MediaStream?) {}
                override fun onRemoveStream(p0: MediaStream?) {}
                override fun onDataChannel(p0: DataChannel?) {}
                override fun onRenegotiationNeeded() {}
                override fun onIceConnectionReceivingChange(p0: Boolean) {}
            }
        )

        // Add audio track
        val audioConstraints = MediaConstraints()
        val audioSource = factory.createAudioSource(audioConstraints)
        localAudioTrack = factory.createAudioTrack("ARDAMSa0", audioSource)
        peerConnection?.addTrack(localAudioTrack, listOf("ARDAMS"))

        // Add video track if requested
        if (withVideo) {
            val videoCapturer = createCameraCapturer(context)
            val surfaceHelper = SurfaceTextureHelper.create("CaptureThread",
                EglBase.create().eglBaseContext)
            val videoSource = factory.createVideoSource(videoCapturer.isScreencast)
            videoCapturer.initialize(surfaceHelper, context, videoSource.capturerObserver)
            videoCapturer.startCapture(1280, 720, 30)
            localVideoTrack = factory.createVideoTrack("ARDAMSv0", videoSource)
            localVideoSink?.let { localVideoTrack?.addSink(it) }
            peerConnection?.addTrack(localVideoTrack, listOf("ARDAMS"))
        }

        _state.update { it.copy(isCallActive = true, isVideoEnabled = withVideo) }

        // Create offer
        peerConnection?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription) {
                peerConnection?.setLocalDescription(SdpObserverAdapter(), sdp)
                wsClient.sendRaw(kotlinx.serialization.json.buildJsonObject {
                    put("type", kotlinx.serialization.json.JsonPrimitive("webrtc_offer"))
                    put("sdp", kotlinx.serialization.json.JsonPrimitive(sdp.description))
                }.toString())
                _state.update { it.copy(localSdp = sdp.description) }
            }
            override fun onCreateFailure(error: String) {
                _state.update { it.copy(error = "Offer failed: $error") }
            }
            override fun onSetSuccess() {}
            override fun onSetFailure(p0: String?) {}
        }, MediaConstraints())
    }

    fun handleRemoteAnswer(sdp: String) {
        val sessionDesc = SessionDescription(SessionDescription.Type.ANSWER, sdp)
        peerConnection?.setRemoteDescription(SdpObserverAdapter(), sessionDesc)
    }

    fun handleRemoteOffer(sdp: String) {
        val sessionDesc = SessionDescription(SessionDescription.Type.OFFER, sdp)
        peerConnection?.setRemoteDescription(SdpObserverAdapter(), sessionDesc)
        peerConnection?.createAnswer(object : SdpObserver {
            override fun onCreateSuccess(answer: SessionDescription) {
                peerConnection?.setLocalDescription(SdpObserverAdapter(), answer)
                wsClient.sendRaw(kotlinx.serialization.json.buildJsonObject {
                    put("type", kotlinx.serialization.json.JsonPrimitive("webrtc_answer"))
                    put("sdp", kotlinx.serialization.json.JsonPrimitive(answer.description))
                }.toString())
            }
            override fun onCreateFailure(error: String) {
                _state.update { it.copy(error = "Answer failed: $error") }
            }
            override fun onSetSuccess() {}
            override fun onSetFailure(p0: String?) {}
        }, MediaConstraints())
    }

    fun addIceCandidate(sdp: String, sdpMid: String, sdpMLineIndex: Int) {
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, sdp))
    }

    fun toggleAudio() {
        val enabled = !(_state.value.isAudioEnabled)
        localAudioTrack?.setEnabled(enabled)
        _state.update { it.copy(isAudioEnabled = enabled) }
    }

    fun toggleVideo() {
        val enabled = !(_state.value.isVideoEnabled)
        localVideoTrack?.setEnabled(enabled)
        _state.update { it.copy(isVideoEnabled = enabled) }
    }

    fun endCall() {
        localAudioTrack?.dispose()
        localVideoTrack?.dispose()
        peerConnection?.close()
        peerConnection = null
        localAudioTrack = null
        localVideoTrack = null
        _state.update { it.copy(isCallActive = false, isAudioEnabled = true, isVideoEnabled = false) }
    }

    private fun createCameraCapturer(context: Context): VideoCapturer {
        val enumerator = Camera2Enumerator(context)
        val frontCamera = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
        val backCamera  = enumerator.deviceNames.firstOrNull { enumerator.isBackFacing(it) }
        return enumerator.createCapturer(frontCamera ?: backCamera ?: "", null)
    }
}

private class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(p0: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(p0: String?) {}
    override fun onSetFailure(p0: String?) {}
}
