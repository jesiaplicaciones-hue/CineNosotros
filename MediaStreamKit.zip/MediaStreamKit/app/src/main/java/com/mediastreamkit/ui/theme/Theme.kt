package com.mediastreamkit.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

// ─── Color Tokens ────────────────────────────────────────────────────────────

// Default: Dark Cosmic Purple
val CosmicPurplePrimary         = Color(0xFF6A1B9A)
val CosmicPurpleSecondary       = Color(0xFF8E24AA)
val CosmicPurpleTertiary        = Color(0xFFCE93D8)
val CosmicPurpleBackground      = Color(0xFF120024)
val CosmicPurpleSurface         = Color(0xFF1E0036)
val CosmicPurpleSurfaceVariant  = Color(0xFF2A0050)
val CosmicPurpleOnPrimary       = Color(0xFFFFFFFF)
val CosmicPurpleOnBackground    = Color(0xFFEDE7F6)
val CosmicPurpleOnSurface       = Color(0xFFD1C4E9)
val CosmicPurpleError           = Color(0xFFCF6679)
val CosmicPurpleOutline         = Color(0xFF7E57C2)
val CosmicPurpleAccent          = Color(0xFFE040FB)
val OnlineGreen                 = Color(0xFF4CAF50)

// Galaxy Blue
val GalaxyBluePrimary           = Color(0xFF0D47A1)
val GalaxyBlueSecondary         = Color(0xFF1565C0)
val GalaxyBlueBackground        = Color(0xFF000A1F)
val GalaxyBlueSurface           = Color(0xFF001433)
val GalaxyBlueTertiary          = Color(0xFF82B1FF)

// Romantic Pink
val RomanticPinkPrimary         = Color(0xFFAD1457)
val RomanticPinkSecondary       = Color(0xFFC2185B)
val RomanticPinkBackground      = Color(0xFF1A0010)
val RomanticPinkSurface         = Color(0xFF2D0020)
val RomanticPinkTertiary        = Color(0xFFF48FB1)

// Elegant Black
val ElegantBlackPrimary         = Color(0xFF455A64)
val ElegantBlackSecondary       = Color(0xFF607D8B)
val ElegantBlackBackground      = Color(0xFF050505)
val ElegantBlackSurface         = Color(0xFF0F0F0F)
val ElegantBlackTertiary        = Color(0xFFB0BEC5)

// ─── Color Scheme Definitions ─────────────────────────────────────────────────

private val CosmicPurpleColorScheme = darkColorScheme(
    primary             = CosmicPurplePrimary,
    onPrimary           = CosmicPurpleOnPrimary,
    primaryContainer    = Color(0xFF3A006F),
    onPrimaryContainer  = CosmicPurpleTertiary,
    secondary           = CosmicPurpleSecondary,
    onSecondary         = CosmicPurpleOnPrimary,
    secondaryContainer  = Color(0xFF4A0072),
    onSecondaryContainer= Color(0xFFE8B4F8),
    tertiary            = CosmicPurpleTertiary,
    onTertiary          = Color(0xFF4A0072),
    background          = CosmicPurpleBackground,
    onBackground        = CosmicPurpleOnBackground,
    surface             = CosmicPurpleSurface,
    onSurface           = CosmicPurpleOnSurface,
    surfaceVariant      = CosmicPurpleSurfaceVariant,
    onSurfaceVariant    = Color(0xFFB39DDB),
    error               = CosmicPurpleError,
    onError             = Color(0xFF370009),
    outline             = CosmicPurpleOutline,
    outlineVariant      = Color(0xFF4527A0),
    scrim               = Color(0xFF000000)
)

private val GalaxyBlueColorScheme = darkColorScheme(
    primary             = GalaxyBluePrimary,
    onPrimary           = Color(0xFFFFFFFF),
    primaryContainer    = Color(0xFF002171),
    onPrimaryContainer  = GalaxyBlueTertiary,
    secondary           = GalaxyBlueSecondary,
    onSecondary         = Color(0xFFFFFFFF),
    secondaryContainer  = Color(0xFF003090),
    onSecondaryContainer= Color(0xFF90CAF9),
    tertiary            = GalaxyBlueTertiary,
    onTertiary          = Color(0xFF003090),
    background          = GalaxyBlueBackground,
    onBackground        = Color(0xFFE3F2FD),
    surface             = GalaxyBlueSurface,
    onSurface           = Color(0xFFBBDEFB),
    surfaceVariant      = Color(0xFF002040),
    onSurfaceVariant    = Color(0xFF90CAF9),
    error               = Color(0xFFCF6679),
    outline             = Color(0xFF1976D2),
)

private val RomanticPinkColorScheme = darkColorScheme(
    primary             = RomanticPinkPrimary,
    onPrimary           = Color(0xFFFFFFFF),
    primaryContainer    = Color(0xFF7B0038),
    onPrimaryContainer  = RomanticPinkTertiary,
    secondary           = RomanticPinkSecondary,
    onSecondary         = Color(0xFFFFFFFF),
    secondaryContainer  = Color(0xFF8C0042),
    onSecondaryContainer= Color(0xFFF8BBD0),
    tertiary            = RomanticPinkTertiary,
    onTertiary          = Color(0xFF8C0042),
    background          = RomanticPinkBackground,
    onBackground        = Color(0xFFFCE4EC),
    surface             = RomanticPinkSurface,
    onSurface           = Color(0xFFF48FB1),
    surfaceVariant      = Color(0xFF3D0028),
    onSurfaceVariant    = Color(0xFFF48FB1),
    error               = Color(0xFFCF6679),
    outline             = Color(0xFFE91E63),
)

private val ElegantBlackColorScheme = darkColorScheme(
    primary             = ElegantBlackPrimary,
    onPrimary           = Color(0xFFFFFFFF),
    primaryContainer    = Color(0xFF263238),
    onPrimaryContainer  = ElegantBlackTertiary,
    secondary           = ElegantBlackSecondary,
    onSecondary         = Color(0xFFFFFFFF),
    secondaryContainer  = Color(0xFF37474F),
    onSecondaryContainer= Color(0xFFCFD8DC),
    tertiary            = ElegantBlackTertiary,
    onTertiary          = Color(0xFF37474F),
    background          = ElegantBlackBackground,
    onBackground        = Color(0xFFECEFF1),
    surface             = ElegantBlackSurface,
    onSurface           = Color(0xFFCFD8DC),
    surfaceVariant      = Color(0xFF1C1C1C),
    onSurfaceVariant    = Color(0xFF90A4AE),
    error               = Color(0xFFCF6679),
    outline             = Color(0xFF546E7A),
)

// ─── Theme Enum ───────────────────────────────────────────────────────────────

enum class AppTheme(val displayName: String, val prefKey: String) {
    COSMIC_PURPLE("Púrpura Cósmico", "cosmic_purple"),
    GALAXY_BLUE("Azul Galaxia", "galaxy_blue"),
    ROMANTIC_PINK("Rosa Romántico", "romantic_pink"),
    ELEGANT_BLACK("Negro Elegante", "elegant_black");

    companion object {
        fun fromKey(key: String) = entries.find { it.prefKey == key } ?: COSMIC_PURPLE
    }
}

// ─── Extra Colors CompositionLocal ────────────────────────────────────────────

data class MskExtendedColors(
    val accent: Color = CosmicPurpleAccent,
    val onlineIndicator: Color = OnlineGreen,
    val starParticle: Color = Color(0xFFCE93D8),
    val cardGradientStart: Color = Color(0xFF2A0050),
    val cardGradientEnd: Color = Color(0xFF120024),
    val chatBubbleOwn: Color = Color(0xFF6A1B9A),
    val chatBubbleOther: Color = Color(0xFF2A0050),
    val syncActive: Color = Color(0xFF00E5FF),
)

val LocalMskColors = compositionLocalOf { MskExtendedColors() }

val MaterialTheme.mskColors: MskExtendedColors
    @Composable @ReadOnlyComposable get() = LocalMskColors.current

// ─── Root Theme Composable ────────────────────────────────────────────────────

@Composable
fun MediaStreamKitTheme(
    appTheme: AppTheme = AppTheme.COSMIC_PURPLE,
    content: @Composable () -> Unit
) {
    val colorScheme = when (appTheme) {
        AppTheme.COSMIC_PURPLE -> CosmicPurpleColorScheme
        AppTheme.GALAXY_BLUE   -> GalaxyBlueColorScheme
        AppTheme.ROMANTIC_PINK -> RomanticPinkColorScheme
        AppTheme.ELEGANT_BLACK -> ElegantBlackColorScheme
    }

    val extendedColors = when (appTheme) {
        AppTheme.COSMIC_PURPLE -> MskExtendedColors(
            accent = CosmicPurpleAccent,
            starParticle = Color(0xFFCE93D8),
            cardGradientStart = Color(0xFF2A0050),
            cardGradientEnd   = Color(0xFF120024),
            chatBubbleOwn     = CosmicPurplePrimary,
            chatBubbleOther   = CosmicPurpleSurfaceVariant,
        )
        AppTheme.GALAXY_BLUE -> MskExtendedColors(
            accent = Color(0xFF40C4FF),
            starParticle = Color(0xFF82B1FF),
            cardGradientStart = Color(0xFF002040),
            cardGradientEnd   = GalaxyBlueBackground,
            chatBubbleOwn     = GalaxyBluePrimary,
            chatBubbleOther   = Color(0xFF002040),
        )
        AppTheme.ROMANTIC_PINK -> MskExtendedColors(
            accent = Color(0xFFFF4081),
            starParticle = Color(0xFFF48FB1),
            cardGradientStart = Color(0xFF3D0028),
            cardGradientEnd   = RomanticPinkBackground,
            chatBubbleOwn     = RomanticPinkPrimary,
            chatBubbleOther   = Color(0xFF3D0028),
        )
        AppTheme.ELEGANT_BLACK -> MskExtendedColors(
            accent = Color(0xFF80DEEA),
            starParticle = Color(0xFF90A4AE),
            cardGradientStart = Color(0xFF1C1C1C),
            cardGradientEnd   = ElegantBlackBackground,
            chatBubbleOwn     = ElegantBlackPrimary,
            chatBubbleOther   = Color(0xFF1C1C1C),
        )
    }

    CompositionLocalProvider(LocalMskColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography  = MskTypography,
            shapes      = MskShapes,
            content     = content
        )
    }
}
