package com.mediastreamkit.core.service

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.work.WorkManager
import timber.log.Timber

class DownloadForegroundService : Service() {

    private val NOTIF_ID = 1001

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildForegroundNotification())
        Timber.d("DownloadForegroundService started")
        return START_STICKY
    }

    private fun buildForegroundNotification(): Notification =
        NotificationCompat.Builder(this, "msk_download_channel")
            .setContentTitle("MediaStreamKit")
            .setContentText("Descargando contenido para modo offline…")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
