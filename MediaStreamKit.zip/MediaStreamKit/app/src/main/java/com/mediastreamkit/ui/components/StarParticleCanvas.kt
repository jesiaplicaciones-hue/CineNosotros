package com.mediastreamkit.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mediastreamkit.ui.theme.LocalMskColors
import kotlin.math.sin
import kotlin.random.Random

private const val PARTICLE_COUNT = 80

data class StarParticle(
    val x: Float,          // 0..1 fraction of canvas width
    val y: Float,          // 0..1 fraction of canvas height
    val radius: Float,     // dp
    val phaseOffset: Float // animation phase offset 0..2π
)

/**
 * Efficient star-particle background.
 * Each star pulses independently using a sine curve derived from
 * a shared infinite animation clock — no per-particle coroutine overhead.
 * Rendering is purely canvas-based so no GPU texture allocations occur.
 */
@Composable
fun StarParticleCanvas(
    modifier: Modifier = Modifier,
    particleCount: Int = PARTICLE_COUNT,
    minRadius: Dp = 0.8.dp,
    maxRadius: Dp = 2.4.dp,
    color: Color = LocalMskColors.current.starParticle,
    speed: Float = 2000f // ms per cycle
) {
    val particles = remember(particleCount) {
        List(particleCount) {
            StarParticle(
                x           = Random.nextFloat(),
                y           = Random.nextFloat(),
                radius      = Random.nextFloat() * (maxRadius.value - minRadius.value) + minRadius.value,
                phaseOffset = Random.nextFloat() * (2f * Math.PI.toFloat())
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "stars")
    val tick by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue  = (2f * Math.PI.toFloat()),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = speed.toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "starTick"
    )

    Canvas(modifier = modifier) {
        particles.forEach { star ->
            val alpha = ((sin(tick + star.phaseOffset) + 1f) / 2f)
                .coerceIn(0.05f, 1f)
            drawCircle(
                color  = color.copy(alpha = alpha * 0.8f),
                radius = star.radius * density,
                center = Offset(star.x * size.width, star.y * size.height)
            )
        }
    }
}
