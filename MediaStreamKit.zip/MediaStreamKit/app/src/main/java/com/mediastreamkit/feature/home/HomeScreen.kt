package com.mediastreamkit.feature.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.mediastreamkit.core.domain.model.MediaItem
import com.mediastreamkit.core.domain.model.PresenceStatus
import com.mediastreamkit.core.utils.toTmdbImageUrl
import com.mediastreamkit.ui.components.StarParticleCanvas
import com.mediastreamkit.ui.theme.OnlineGreen
import com.mediastreamkit.ui.theme.mskColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    userId: Int,
    onMediaClick: (MediaItem) -> Unit,
    onChatClick: () -> Unit,
    onLunaClick: () -> Unit,
    onSettingsClick: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("MediaStreamKit", style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary)
                        PresenceIndicator(state.presenceStatus)
                    }
                },
                actions = {
                    // Partner presence
                    PresenceChip(
                        label = "Compañero",
                        status = state.partnerPresence
                    )
                    // Chat with badge
                    BadgedBox(
                        badge = {
                            if (state.unreadMessages > 0)
                                Badge { Text(state.unreadMessages.toString()) }
                        }
                    ) {
                        IconButton(onClick = onChatClick) {
                            Icon(Icons.Default.Chat, "Chat",
                                tint = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    IconButton(onClick = onLunaClick) {
                        Icon(Icons.Default.AutoAwesome, "Luna AI",
                            tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onSettingsClick) {
                        Icon(Icons.Default.Settings, "Ajustes",
                            tint = MaterialTheme.colorScheme.onSurface)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)
                )
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize()) {
            StarParticleCanvas(
                Modifier.fillMaxSize(),
                particleCount = 40
            )

            if (state.isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.primary
                )
            } else if (state.sections.isEmpty()) {
                EmptyHomeState(modifier = Modifier.align(Alignment.Center))
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    state.sections.forEach { section ->
                        item(key = section.title) {
                            MediaRow(
                                section = section,
                                onItemClick = onMediaClick
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaRow(
    section: HomeSectionData,
    onItemClick: (MediaItem) -> Unit
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = section.title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = {}) {
                Text("Ver todo", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary)
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(section.items, key = { it.id }) { item ->
                MediaCard(item = item, onClick = { onItemClick(item) })
            }
        }
    }
}

@Composable
private fun MediaCard(item: MediaItem, onClick: () -> Unit) {
    val colors = MaterialTheme.mskColors

    Card(
        onClick = onClick,
        modifier = Modifier
            .width(130.dp)
            .height(200.dp),
        shape = MaterialTheme.shapes.medium,
        elevation = CardDefaults.cardElevation(6.dp)
    ) {
        Box(Modifier.fillMaxSize()) {
            AsyncImage(
                model = item.posterPath.toTmdbImageUrl("w300"),
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                androidx.compose.ui.graphics.Color.Transparent,
                                colors.cardGradientEnd.copy(alpha = 0.85f)
                            )
                        )
                    )
            )
            // Progress bar
            if (item.watchedProgress > 0f && !item.isWatched) {
                LinearProgressIndicator(
                    progress = { item.watchedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .align(Alignment.BottomCenter),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
            Text(
                text = item.title,
                style = MaterialTheme.typography.labelSmall,
                color = androidx.compose.ui.graphics.Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            )
            if (item.isDownloaded) {
                Icon(
                    Icons.Default.DownloadDone,
                    contentDescription = "Descargado",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun PresenceIndicator(status: PresenceStatus) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(MaterialTheme.shapes.extraSmall)
            .background(
                if (status == PresenceStatus.ONLINE) OnlineGreen
                else MaterialTheme.colorScheme.outline
            )
    )
}

@Composable
private fun PresenceChip(label: String, status: PresenceStatus) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(MaterialTheme.shapes.small)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(MaterialTheme.shapes.extraSmall)
                .background(if (status == PresenceStatus.ONLINE) OnlineGreen else MaterialTheme.colorScheme.outline)
        )
        Text(label, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyHomeState(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(Icons.Default.MovieFilter, null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
        Text("Tu catálogo está vacío",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground)
        Text("Importa títulos desde Luna AI o la sección de ajustes",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
