package com.mediastreamkit

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mediastreamkit.core.data.local.MskDatabase
import com.mediastreamkit.core.data.local.dao.MediaItemDao
import com.mediastreamkit.core.data.local.dao.UserProfileDao
import com.mediastreamkit.core.data.local.dao.SharedListDao
import com.mediastreamkit.core.data.local.dao.NoteDao
import com.mediastreamkit.core.data.local.entities.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DatabaseTest {

    private lateinit var db: MskDatabase
    private lateinit var userDao: UserProfileDao
    private lateinit var mediaDao: MediaItemDao
    private lateinit var sharedListDao: SharedListDao
    private lateinit var noteDao: NoteDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        // Use unencrypted in-memory DB for tests
        db = Room.inMemoryDatabaseBuilder(context, MskDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        userDao      = db.userProfileDao()
        mediaDao     = db.mediaItemDao()
        sharedListDao = db.sharedListDao()
        noteDao      = db.noteDao()
    }

    @After
    fun closeDb() { db.close() }

    // ── User Profile Tests ────────────────────────────────────────────────────

    @Test
    fun insertAndRetrieveUserProfile() = runBlocking {
        val profile = UserProfileEntity(
            id = 0,
            username = "TestUser",
            avatarId = 2,
            profilePicture = null,
            passwordHash = "hashedpw"
        )
        userDao.upsert(profile)
        val retrieved = userDao.getById(0)
        assertNotNull(retrieved)
        assertEquals("TestUser", retrieved?.username)
        assertEquals(2, retrieved?.avatarId)
    }

    @Test
    fun countProfilesIsCorrectAfterInserts() = runBlocking {
        assertEquals(0, userDao.count())
        userDao.upsert(UserProfileEntity(0, "User1", 0, null, "hash1"))
        assertEquals(1, userDao.count())
        userDao.upsert(UserProfileEntity(1, "User2", 1, null, "hash2"))
        assertEquals(2, userDao.count())
    }

    @Test
    fun upsertUpdatesExistingProfile() = runBlocking {
        userDao.upsert(UserProfileEntity(0, "OldName", 0, null, "hash"))
        userDao.upsert(UserProfileEntity(0, "NewName", 0, null, "hash"))
        val retrieved = userDao.getById(0)
        assertEquals("NewName", retrieved?.username)
    }

    @Test
    fun observeAllProfilesEmitsCorrectly() = runBlocking {
        userDao.upsert(UserProfileEntity(0, "Alice", 0, null, "h1"))
        userDao.upsert(UserProfileEntity(1, "Bob",   1, null, "h2"))
        val profiles = userDao.observeAll().first()
        assertEquals(2, profiles.size)
        assertEquals("Alice", profiles[0].username)
        assertEquals("Bob",   profiles[1].username)
    }

    // ── Media Item Tests ──────────────────────────────────────────────────────

    @Test
    fun insertAndQueryMediaItem() = runBlocking {
        val item = MediaItemEntity(
            id = 100, tmdbId = 100, title = "Test Movie",
            posterPath = "/test.jpg", backdropPath = null,
            runtimeMinutes = 120, genres = listOf("Acción", "Drama"),
            releaseDate = "2024-01-01", overview = "A great film",
            sagaId = null, sagaName = null,
            category = "CATEGORY_A",
            isWatched = false, watchedProgress = 0f, isDownloaded = false
        )
        mediaDao.upsert(item)
        val retrieved = mediaDao.getById(100)
        assertNotNull(retrieved)
        assertEquals("Test Movie", retrieved?.title)
        assertEquals(listOf("Acción", "Drama"), retrieved?.genres)
    }

    @Test
    fun continueWatchingOnlyShowsInProgressItems() = runBlocking {
        mediaDao.upsert(MediaItemEntity(1, 1, "Movie A", null, null,
            100, emptyList(), "2024", "", null, null, "CATEGORY_A",
            isWatched = false, watchedProgress = 0.5f, isDownloaded = false))
        mediaDao.upsert(MediaItemEntity(2, 2, "Movie B", null, null,
            100, emptyList(), "2024", "", null, null, "CATEGORY_A",
            isWatched = false, watchedProgress = 0f, isDownloaded = false))
        mediaDao.upsert(MediaItemEntity(3, 3, "Movie C", null, null,
            100, emptyList(), "2024", "", null, null, "CATEGORY_A",
            isWatched = true, watchedProgress = 1f, isDownloaded = false))

        val continueWatching = mediaDao.observeContinueWatching().first()
        assertEquals(1, continueWatching.size)
        assertEquals("Movie A", continueWatching[0].title)
    }

    @Test
    fun updateWatchedStateWorks() = runBlocking {
        mediaDao.upsert(MediaItemEntity(10, 10, "Film", null, null,
            90, emptyList(), "2024", "", null, null, "CATEGORY_B",
            isWatched = false, watchedProgress = 0f, isDownloaded = false))
        mediaDao.updateWatchedState(10, true, 1f)
        val item = mediaDao.getById(10)
        assertTrue(item?.isWatched == true)
        assertEquals(1f, item?.watchedProgress)
    }

    @Test
    fun filterByCategoryReturnsCorrectItems() = runBlocking {
        mediaDao.upsertAll(listOf(
            MediaItemEntity(1, 1, "A1", null, null, 90, emptyList(), "2024", "", null, null,
                "CATEGORY_A", false, 0f, false),
            MediaItemEntity(2, 2, "B1", null, null, 90, emptyList(), "2024", "", null, null,
                "CATEGORY_B", false, 0f, false),
            MediaItemEntity(3, 3, "A2", null, null, 90, emptyList(), "2024", "", null, null,
                "CATEGORY_A", false, 0f, false)
        ))
        val catA = mediaDao.observeByCategory("CATEGORY_A").first()
        assertEquals(2, catA.size)
        val catB = mediaDao.observeByCategory("CATEGORY_B").first()
        assertEquals(1, catB.size)
    }

    // ── Shared List Tests ─────────────────────────────────────────────────────

    @Test
    fun addAndRemoveFromSharedList() = runBlocking {
        // Insert media first (FK constraint)
        mediaDao.upsert(MediaItemEntity(50, 50, "SharedFilm", null, null,
            100, emptyList(), "2024", "", null, null, "CATEGORY_A",
            false, 0f, false))
        sharedListDao.add(SharedListEntity(mediaId = 50, addedByUserId = 0))
        assertTrue(sharedListDao.exists(50))
        sharedListDao.remove(50)
        assertFalse(sharedListDao.exists(50))
    }

    @Test
    fun sharedListObservableEmitsCorrectData() = runBlocking {
        mediaDao.upsert(MediaItemEntity(60, 60, "ListFilm", null, null,
            90, emptyList(), "2024", "", null, null, "CATEGORY_A",
            false, 0f, false))
        sharedListDao.add(SharedListEntity(mediaId = 60, addedByUserId = 1))
        val list = sharedListDao.observeSharedList().first()
        assertEquals(1, list.size)
        assertEquals("ListFilm", list[0].title)
    }

    // ── Notes Tests ───────────────────────────────────────────────────────────

    @Test
    fun insertAndRetrieveNote() = runBlocking {
        val now = System.currentTimeMillis()
        val note = NoteEntity(
            noteId = "note-001", userId = 0, mediaId = null,
            content = "This is a test note",
            createdAt = now, updatedAt = now, isPinned = false
        )
        noteDao.upsert(note)
        val notes = noteDao.observeByUser(0).first()
        assertEquals(1, notes.size)
        assertEquals("This is a test note", notes[0].content)
    }

    @Test
    fun pinnedNotesAppearFirst() = runBlocking {
        val now = System.currentTimeMillis()
        noteDao.upsert(NoteEntity("n1", 0, null, "Normal note", now, now, false))
        noteDao.upsert(NoteEntity("n2", 0, null, "Pinned note", now, now, true))
        val notes = noteDao.observeByUser(0).first()
        // Room orders by isPinned DESC
        assertTrue("First note should be pinned", notes[0].isPinned)
        assertFalse("Second note should not be pinned", notes[1].isPinned)
    }

    @Test
    fun deleteNoteRemovesIt() = runBlocking {
        val now = System.currentTimeMillis()
        noteDao.upsert(NoteEntity("del-001", 0, null, "To delete", now, now, false))
        noteDao.delete("del-001")
        val notes = noteDao.observeByUser(0).first()
        assertTrue(notes.isEmpty())
    }
}
